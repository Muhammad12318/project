-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2024 at 05:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_reviews_uk`
--

-- --------------------------------------------------------

--
-- Table structure for table `messenger_messages`
--

CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `duration` int(11) NOT NULL,
  `release_year` varchar(255) NOT NULL,
  `genres` varchar(255) NOT NULL,
  `casts` varchar(1000) DEFAULT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `country` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `thumbnail_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `created_by_id`, `title`, `duration`, `release_year`, `genres`, `casts`, `description`, `created_at`, `country`, `language`, `thumbnail_path`) VALUES
(1, 5, 'Incredible Hulk', 112, '2008', 'Animation, action, superhero, horror', 'Mark Ruffalo', 'The Incredible Hulk is a 2008 American superhero film based on the Marvel Comics character the Hulk. Produced by Marvel Studios and distributed by Universal Pictures,[a] it is the second film in the Marvel Cinematic Universe (MCU). It was directed by Louis Leterrier from a screenplay by Zak Penn, and stars Edward Norton as Bruce Banner alongside Liv Tyler, Tim Roth, William Hurt, Tim Blake Nelson, Ty Burrell, and Christina Cabot. In the film, Bruce Banner becomes the Hulk as an unwitting pawn in a military scheme to reinvigorate the \"Super-Soldier\" program through gamma radiation. Banner goes on the run from the military while attempting to cure himself of the Hulk.', '2023-12-08 11:53:59', 'United States', 'English', 'movies_thumbnail/The-Incredible-Hulk-film-poster-6572f5c88cb9a.jpg'),
(2, 5, 'Scream VI', 122, '2023', 'Horror, Thriller', 'Jenna Ortega', 'Scream VI is a 2023 American slasher film directed by Matt Bettinelli-Olpin and Tyler Gillett, and written by James Vanderbilt and Guy Busick. It is the sequel to Scream (2022) and the sixth installment in the Scream film series. The film stars Melissa Barrera, Jenna Ortega, Jasmin Savoy Brown, Mason Gooding, Hayden Panettiere and Courteney Cox, all reprising their roles from previous installments, with Josh Segarra, Jack Champion, Devyn Nekoda, Liana Liberato, Tony Revolori, Samara Weaving, Henry Czerny and Dermot Mulroney joining the ensemble cast. The plot follows a new Ghostface killer, who begins targeting the survivors of the Woodsboro murders in New York City.', '2023-12-08 11:59:11', 'United States', 'English', 'movies_thumbnail/MV5BODBjM2M4YTQtNmJlMS00MGU2LWI4ZGYtZTA1MzdmZDAyMjFkXkEyXkFqcGdeQXVyODE5NzE3OTE-at-V1-FMjpg-UX1000-6572f6ffb634d.jpg'),
(3, 5, 'Iron Man', 122, '2018', 'Animation, action, superhero, Drama', 'Robert Downey Jr', 'Iron Man is a superhero appearing in American comic books published by Marvel Comics. Co-created by writer and editor Stan Lee, developed by scripter Larry Lieber, and designed by artists Don Heck and Jack Kirby, the character first appeared in Tales of Suspense #39 in 1963, and received his own title with Iron Man #1 in 1968. Shortly after his creation, Iron Man was a founding member of a superhero team, the Avengers, with Thor, Ant-Man, Wasp and the Hulk. Iron Man stories, individually and with the Avengers, have been published consistently since the character\'s creation.', '2023-12-08 12:02:18', 'United States', 'Enhlish', 'movies_thumbnail/7885686-3-6572f7bad8181.png'),
(4, 5, 'Joker', 122, '2019', 'Horror, Thriller, Comedy', 'Heath Ledger', 'Joker is a 2019 American neo-noir psychological thriller film directed by Todd Phillips, who also co-wrote the screenplay with Scott Silver. The film, based on DC Comics characters, stars Joaquin Phoenix as Joker. Set in 1981, it follows Arthur Fleck, a failed clown and aspiring stand-up comic whose descent into mental illness and nihilism inspires a violent countercultural revolution against the wealthy in a decaying Gotham City. Robert De Niro, Zazie Beetz and Frances Conroy appear in supporting roles. Distributed by Warner Bros. Pictures, Joker was produced by Warner Bros. Pictures and DC Films in association with Village Roadshow Pictures, Bron Creative and Joint Effort.', '2023-12-08 12:04:20', 'United States', 'English', 'movies_thumbnail/thejoker-action-batman-movie-6572f835126ca.jpg'),
(5, 5, 'Inception', 150, '2010', 'Science Fiction, Action,', 'Leonardo Dicaprio, Cillian Murphy', 'Inception is a 2010 science fiction action film[4][5][6] written and directed by Christopher Nolan, who also produced the film with Emma Thomas, his wife. The film stars Leonardo DiCaprio as a professional thief who steals information by infiltrating the subconscious of his targets. He is offered a chance to have his criminal history erased, as payment for the implantation of another person\'s idea into a target\'s subconscious.[7] The ensemble cast includes Ken Watanabe, Joseph Gordon-Levitt, Marion Cotillard, Elliot Page,[a] Tom Hardy, Cillian Murphy, Tom Berenger, Dileep Rao and Michael Caine.', '2023-12-08 12:06:14', 'United States,United Kingdom', 'English', 'movies_thumbnail/p7825626-p-v8-af-6572f8a6329e2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `movie_review`
--

CREATE TABLE `movie_review` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `description` longtext NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `movie_review`
--

INSERT INTO `movie_review` (`id`, `user_id`, `movie_id`, `created_at`, `description`, `rating`) VALUES
(1, 5, 1, '2023-12-08 14:14:32', 'As I would like to think, out of all the Hulk motion pictures I\'ve seen this one is 100 percent the best. The Hulk looks tumultuous as the Hulk ought to be. The Hulk versus The Evil entity was an electrifying battle. I really, believed that Hulk planned to lose and I would\'ve been astounded assuming he did. One thing that I would\'ve preferred in the other Wonder motion pictures was that assuming Bruce and Natasha enjoyed one another, I mean why not be together. I would\'ve enjoyed it in the event that Wonder would\'ve investigated a greater amount of their adoration somewhat to make Bruce not simply a concealing man doing whatever it takes not to blow his top however to see him as all the more a human rather than a researcher and a furious beast in fact.\r\n\r\nI love The Staggering Hulk.It is my #1 MCU movie,which is definetly a disliked opinion,considering the way that motion pictures like Iron Man and Avengers:Endgame got a lot higher basic evaluations and were by and large preferred better by the overall public.But I think it gets a terrible rap.The CGI designs are shocking and the regions look beautiful.I additionally love the plan for the Hulk.While Mark Ruffalo is a superior Bruce Flag Hulk,I actually love Edward Norton\'s depiction of the character.He portrays Pennant as a researcher who has been living in the shadows,and he executes it very well.And Tim Roth\'s depiction of Emil Blondskey and The Abomanation was done amazingly.And Liv Tyler and William Hurt executed their jobs as Betty and General Ross in an extraordinary way.The secret toward the end for The Pioneer and Tony Starls\' appearance in the post credit scene made me love the film even more.I give this move a 1000/10.', 5),
(2, 5, 3, '2023-12-08 14:14:53', 'This film is astonishing. It is an ideal method for beginning of the MCU (and is improved even due to Final stage). The cast is astonishing and you get the feeling that everybody is attempting there outright best since they need this film to be great. I love the delightful way Tony Unmistakable beginnings of as a person that is no where close to a legend to finishing the film as one. The film is shockingly fierce and the utilization of Terroist in the film provides it with a feeling of authenticity and genuine severity that different movies miss the mark on issue how extraordinary they are. The parody is so amusing and is something that hasn\'t left the establishment. Over all fabulous film not the best yet one of them.\r\n\r\nIronman-what an amzing film!!\r\nwith an extraordinary cast and pleasant activity, this was a decent beginning for the mcu and was perfect to see a mcu film without the heaviness of the remainder of the universe on it\'s shoulders.now the main half is unbelievably borning, however the subsequent part compensates for the first hour.tony and pepper were astounding characters and truly the Obadiah stane reprobate is so bland.so unsurprising, and his motiviation is so reused.the finishing was great and truly generally it was a decent film.you can appreciate it in the event that you have the persistence to endure the principal half .likewise terence howard is soo underused and I truly thought pepper potts (gwyneth paltrow) would simply be like MJ from raimiverse-shouting her head off ready to be saved by the hero,but pepper assumes a significant part in the peak.', 5),
(3, 5, 4, '2023-12-08 14:15:23', 'Joker is a marvelous film, bound to be set in opposition to Ledger\'s The Dim Knight execution for the title of conclusive on-screen depiction of the person.\r\n\r\nJoaquin Phoenix gives a masterpiece execution, valiant and staggering in its personal profundity and rawness. There is noxiousness leaking from his actual pores. At first it is a piece harder to recognize, in light of the fact that Phoenix so breathtakingly portrays the manners by which the Joker grapples with himself to mask his psychotic propensities. Be that as it may, slowly, horrendously, he permits us to see increasingly more of it. Furthermore, as we witness it, we understand it\'s anything but a change but instead a disclosure of what was in every case scarcely held back underneath the surface. Also, we review prior minutes, and we understand the evil was there as well, yet it terrified him the manner in which it alarms us, so he covered it.\r\n\r\nThere was a risk in Phillips\' choice to take motivation from Martin Scorsese.Phillips accomplishes something else, however, and in doing so catches a more genuine and seriously convincing quintessence of what the Joker truly is he constructs an illusory authenticity, allowing us to enter the horrible discernments and misdirections of the Joker, moving perspectives smudged road level validness toward a modified condition of cognizance. Everything appears to be genuine, and simultaneously dreamlike, similar to a suppressed, drug-prompted insight of hyper-reality.\r\n\r\nThe cinematography in Joker is fantastic, as well. Lawrence Sher accomplishes something amazing this time.Hildur Guðnadóttir\'s score is one more convincing piece of Joker.\r\n\r\nThe supporting cast are eminent too. Zazie Beetz is phenomenal as Joker\'s neighbor and would-be object of his fondness, in a job that will shock you at least a time or two. It\'s a deft exhibition requiring cautious equilibrium and nuance, which Beetz easily supplies. Frances Conroy is especially noteworthy in a downplayed, dismal execution as Joker\'s mom. Robert De Niro is... all things considered, he\'s De Niro, so obviously he\'s perfect as usual, yet there\'s additional flavor to his presentation because of his lead job in The Lord of Parody and the inversion of positions in Joker.\r\n\r\nIn any case, I should return to Phoenix once more, for it is his exhibition that all the other things depends on and settles upon. It is a victory of expertise and responsibility, a competitor for the crown as his best execution to date.', 5),
(4, 5, 2, '2023-12-08 14:59:39', 'A great expansion to the \"SCREAM\" establishment. \"SCREAM 6\" includes the Nastiest kills found in the establishment. Ghostface is wandering the roads of New York City with additional fury and heartlessness then of all time. Was enjoyably shocked by more superb cinematography, groupings and obviously ghostface utilizing a shotgun close to a blade.  Other than the undeniable decision of another setting, the tone is intense and less awkward. Characters are truly determined home with an incredible content, with meta sprinkled all through. It clenches down on the suggesting conversation starter of how far might you at any point truly go with an IP. While keeping up with its trustworthiness. Besides, this is certainly a change from subjects before it. Bringing back the old cast from the last film was smart and decision to make. Numerous minutes all through are strain filled and exceptionally close to home. Shockingly, they all function admirably! With the remarkable person and champion execution\'s by @jennaortega (Tara) and (Sam) @melissabarreram both woodworker sisters put and Helmed at the front of the Crew. In saying this, there are a few issue. It\'s implied, the glaring issue at hand must be Neve Campbells takeoff from the establishment. Trailers worked really hard at stowing away the vast majority of what unfurls on screen inside its strong run time. In any case, tragically my problem is that this film most certainly was feeling the loss of her personality - Sidney Prescott, in specific minutes, as anticipated by most loathsomeness fans, the nonappearance is perceptibly clear in key plot minutes. Its mixed and is a complete disgrace to realize she was not paid sufficiently for the job she birthed during the 90s as a one of a kind scream sovereign. She merits all the most satisfaction on the planet, for the wellbeing of her own I want to believe that she appreciates downtime. In comparable vein I partook in the last film, however totally loved this one much more as a tremendous enthusiast of this notorious slasher establishment. It\'s hopeless, fierce, caring and grievous. By the day\'s end, it works!\r\n fringe mind blowing slasher, effectively awesome \"SCREAM\" since the first.', 5),
(5, 5, 5, '2023-12-08 15:04:57', 'Still one of the most amazing unique movies of the most recent 25 years, Inception is an earth shattering activity show with probably the most complex plot planning this side of dreams and reality.\r\n\r\nThis film should be returned to, discussed, dissected, and rewatched over and over. It will unquestionably develop upon each survey, yet it demonstrates immediately captivating the initial time.\r\n\r\nNolan\'s Inception film, not just keeps you as eager and anxious as ever with unimaginable special visualizations and critical activity set pieces, yet additionally makes you a piece of the riddle tackling group from start to finish\r\nA truly flawlessness, entertaining movie, How i wish i can would watch this movie again for the first time.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`roles`)),
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `first_name`, `last_name`, `mobile`, `country`, `gender`) VALUES
(5, 'admin@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$1CPVu7QHi3hYG1ZgrJX0Y.02nW./lNPtyzOUNu7zqVOHdkxPuC01G', 'Admin', 'User', NULL, NULL, 'unknown'),
(6, 'user@gmail.com', '[\"ROLE_USER\"]', '$2y$13$xpCf2l6iVQGfGf7kP2DEbeAhkqr/FddwUIHr8Ucvl8GqH2s/rs4JG', 'User', 'User', '0155000', 'BD', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  ADD KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  ADD KEY `IDX_75EA56E016BA31DB` (`delivered_at`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1D5EF26FB03A8386` (`created_by_id`);

--
-- Indexes for table `movie_review`
--
ALTER TABLE `movie_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_80841CB3A76ED395` (`user_id`),
  ADD KEY `IDX_80841CB38F93B6FC` (`movie_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `movie_review`
--
ALTER TABLE `movie_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `FK_1D5EF26FB03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `movie_review`
--
ALTER TABLE `movie_review`
  ADD CONSTRAINT `FK_80841CB38F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`),
  ADD CONSTRAINT `FK_80841CB3A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
