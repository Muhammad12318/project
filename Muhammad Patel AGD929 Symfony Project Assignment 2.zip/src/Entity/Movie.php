<?php

namespace App\Entity;

use App\Repository\MovieRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity(repositoryClass: MovieRepository::class)]
class Movie
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['review', 'movie'])]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    #[Groups(['review', 'reviewEdit', 'movie'])]
    private ?string $title = null;

    #[ORM\Column]
    #[Groups(['movie'])]
    private ?int $duration = null;

    #[ORM\Column(length: 255)]
    #[Groups(['movie'])]
    private ?string $release_year = null;

    #[ORM\Column(length: 255)]
    #[Groups(['movie'])]
    private ?string $genres = null;

    #[ORM\Column(length: 1000, nullable: true)]
    #[Groups(['movie'])]
    private ?string $casts = null;

    #[ORM\Column(type: Types::TEXT)]
    #[Groups(['movie'])]
    private ?string $description = null;

    #[ORM\ManyToOne(inversedBy: 'movies')]
    #[ORM\JoinColumn(nullable: false)]
//    #[Groups(['movie'])]
    private ?User $created_by = null;

    #[ORM\Column]
    #[Groups(['movie'])]
    private ?\DateTimeImmutable $created_at = null;

    #[ORM\Column(length: 255)]
    #[Groups(['movie'])]
    private ?string $country = null;

    #[ORM\Column(length: 255)]
    #[Groups(['movie'])]
    private ?string $language = null;

    #[ORM\OneToMany(mappedBy: 'movie', targetEntity: MovieReview::class, orphanRemoval: true)]
    #[Groups(['movie'])]
    private Collection $movieReviews;

    #[ORM\Column(length: 255)]
    #[Groups(['movie'])]
    private ?string $thumbnail_path = null;

    public function __construct()
    {
        $this->movieReviews = new ArrayCollection();
        $this->created_at = new \DateTimeImmutable();
    }

    public function __toString()
    {
        return $this->title;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDuration(): ?int
    {
        return $this->duration;
    }

    public function setDuration(int $duration): static
    {
        $this->duration = $duration;

        return $this;
    }

    public function getReleaseYear(): ?string
    {
        return $this->release_year;
    }

    public function setReleaseYear(string $release_year): static
    {
        $this->release_year = $release_year;

        return $this;
    }

    public function getGenres(): ?string
    {
        return $this->genres;
    }

    public function setGenres(string $genres): static
    {
        $this->genres = $genres;

        return $this;
    }

    public function getCasts(): ?string
    {
        return $this->casts;
    }

    public function setCasts(?string $casts): static
    {
        $this->casts = $casts;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getCreatedBy(): ?User
    {
        return $this->created_by;
    }

    public function setCreatedBy(?User $created_by): static
    {
        $this->created_by = $created_by;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeImmutable $created_at): static
    {
        $this->created_at = $created_at;

        return $this;
    }

    public function getCountry(): ?string
    {
        return $this->country;
    }

    public function setCountry(string $country): static
    {
        $this->country = $country;

        return $this;
    }

    public function getLanguage(): ?string
    {
        return $this->language;
    }

    public function setLanguage(string $language): static
    {
        $this->language = $language;

        return $this;
    }

    /**
     * @return Collection<int, MovieReview>
     */
    public function getMovieReviews(): Collection
    {
        return $this->movieReviews;
    }

    public function addMovieReview(MovieReview $movieReview): static
    {
        if (!$this->movieReviews->contains($movieReview)) {
            $this->movieReviews->add($movieReview);
            $movieReview->setMovie($this);
        }

        return $this;
    }

    public function removeMovieReview(MovieReview $movieReview): static
    {
        if ($this->movieReviews->removeElement($movieReview)) {
            // set the owning side to null (unless already changed)
            if ($movieReview->getMovie() === $this) {
                $movieReview->setMovie(null);
            }
        }

        return $this;
    }

    public function getThumbnailPath(): ?string
    {
        return $this->thumbnail_path;
    }

    public function setThumbnailPath(string $thumbnail_path): static
    {
        $this->thumbnail_path = $thumbnail_path;

        return $this;
    }
}
