<?php

namespace App\Entity;

use App\Repository\MovieReviewRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity(repositoryClass: MovieReviewRepository::class)]
class MovieReview
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['review', 'reviewEdit', 'movie'])]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'movieReviews')]
    #[ORM\JoinColumn(nullable: false)]
    #[Groups(['review', 'reviewEdit'])]
    private ?User $user = null;

    #[ORM\ManyToOne(inversedBy: 'movieReviews')]
    #[ORM\JoinColumn(nullable: false)]
    #[Groups(['review', 'reviewEdit'])]
    private ?Movie $movie = null;

    #[ORM\Column]
    #[Groups(['review', 'reviewEdit'])]
    private ?\DateTimeImmutable $created_at = null;

    #[ORM\Column(type: Types::TEXT)]
    #[Groups(['review', 'reviewEdit', 'movie'])]
    private ?string $description = null;

    #[ORM\Column]
    #[Groups(['review', 'reviewEdit', 'movie'])]
    private ?int $rating = null;

    public function __construct()
    {
        $this->created_at =  new \DateTimeImmutable();
    }

    public function __toString(): string
    {
//        return $this->;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): static
    {
        $this->user = $user;

        return $this;
    }

    public function getMovie(): ?Movie
    {
        return $this->movie;
    }

    public function setMovie(?Movie $movie): static
    {
        $this->movie = $movie;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeImmutable $created_at): static
    {
        $this->created_at = $created_at;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getRating(): ?int
    {
        return $this->rating;
    }

    public function setRating(int $rating): static
    {
        $this->rating = $rating;

        return $this;
    }
}
