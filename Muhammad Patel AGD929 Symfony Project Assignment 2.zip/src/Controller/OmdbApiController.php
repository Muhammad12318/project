<?php

namespace App\Controller;

use App\Connector\OmdbApiConnector;
use GuzzleHttp\Client;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

#[Route("/omdb", name: "app_omdb_")]
class OmdbApiController extends AbstractController
{
    #[Route("/", name: "index")]
    public function index(
        Request $request
    ){
        $client = new Client([
            // Base URI is used with relative requests
            'base_uri' => $this->getParameter('OMDB_API_URL'),
        ]);

        $movieData = [];
        if(trim($request->query->get('s', '')) !== '') {
            $response = $client->get('/', [
                'query' => [
                    'apiKey' => $this->getParameter('OMDB_API_KEY'),
                    's' => $request->query->get('s')
                ]
            ]);

            $movies = json_decode($response->getBody()->getContents(), true);

            foreach($movies['Search'] ?? [] as $movie){
                $res = $client->get('/', [
                    'query' => [
                        'apiKey' => $this->getParameter('OMDB_API_KEY'),
                        'i' => $movie['imdbID']
                    ]
                ]);

                $m = json_decode($res->getBody()->getContents(), true);

                $movieData[] = [
                    'thumbnailPath' => $movie['Poster'],
                    'title' => $movie['Title'],
                    'duration' => $m['Runtime'],
                    'genres' => $m['Genre'],
                    'description' => $m['Plot'],
                    'id' => $movie['imdbID'],
                ];
            }
        }

        return $this->render('omdb/index.html.twig', [
            'movies' => $movieData
        ]);
    }

    #[Route("/{id}", name: "show")]
    public function view(
        $id
    ){
        $client = new Client([
            // Base URI is used with relative requests
            'base_uri' => $this->getParameter('OMDB_API_URL'),
        ]);

        $res = $client->get('/', [
            'query' => [
                'apiKey' => $this->getParameter('OMDB_API_KEY'),
                'i' => $id
            ]
        ]);

        $m = json_decode($res->getBody()->getContents(), true);

        dump($m);

        $movieData = [
            'thumbnailPath' => $m['Poster'],
            'title' => $m['Title'],
            'duration' => $m['Runtime'],
            'genres' => $m['Genre'],
            'description' => $m['Plot'],
            'id' => $m['imdbID'],
            'releaseYear' => $m['Year'],
            'casts' => $m['Actors'],
            'language' => $m['Language'],
            'country' => $m['Country'],
        ];

        return $this->render('omdb/show.html.twig', [
            'movie' => $movieData
        ]);
    }
}
