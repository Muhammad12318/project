<?php

namespace App\Controller;

use App\Entity\Movie;
use App\Form\MovieType;
use App\Repository\MovieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/movie')]
#[IsGranted("ROLE_ADMIN")]
class MovieController extends AbstractController
{
    #[Route('/', name: 'app_admin_movie_index', methods: ['GET'])]
    public function index(MovieRepository $movieRepository): Response
    {
        return $this->render('backend/admin/movie/index.html.twig', [
            'movies' => $movieRepository->findAll(),
            'pageTitle' => "Movies List",
            'actionLink' => "app_admin_movie_new",
        ]);
    }

    #[Route('/new', name: 'app_admin_movie_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SluggerInterface $slugger): Response
    {
        $movie = new Movie();
        $form = $this->createForm(MovieType::class, $movie);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $thumbnail = $form->get('thumbnail')->getData();
            if ($thumbnail) {
                $originalFilename = pathinfo($thumbnail->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $slugger->slug($originalFilename);
                $newFilename = $safeFilename . '-' . uniqid() . '.' . $thumbnail->guessExtension();
                $fileDir = "movies_thumbnail";
                $filePath = "movies_thumbnail/" . $newFilename;
                $fileSystem = new Filesystem();
                $fileSystem->mkdir("$fileDir");
                try {
                    $thumbnail->move($fileDir, $newFilename);
                } catch (\Exception $exception) {
                    echo $exception->getMessage();
                }
                $movie->setThumbnailPath($filePath);
            }

            $movie->setCreatedBy($this->getUser());
            $entityManager->persist($movie);
            $entityManager->flush();

            return $this->redirectToRoute('app_admin_movie_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('backend/admin/movie/new.html.twig', [
            'movie' => $movie,
            'form' => $form,
            'pageTitle' => "Add Movie",
        ]);
    }

    #[Route('/{id}', name: 'app_admin_movie_show', methods: ['GET'])]
    public function show(Movie $movie): Response
    {
        return $this->render('backend/admin/movie/show.html.twig', [
            'movie' => $movie,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_admin_movie_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Movie $movie, EntityManagerInterface $entityManager, SluggerInterface $slugger): Response
    {
        $form = $this->createForm(MovieType::class, $movie);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $thumbnail = $form->get('thumbnail')->getData();
            if ($thumbnail) {
                $originalFilename = pathinfo($thumbnail->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $slugger->slug($originalFilename);
                $newFilename = $safeFilename . '-' . uniqid() . '.' . $thumbnail->guessExtension();
                $fileDir = "movies_thumbnail";
                $filePath = "movies_thumbnail/" . $newFilename;
                $fileSystem = new Filesystem();
                $fileSystem->mkdir("$fileDir");
                try {
                    $thumbnail->move($fileDir, $newFilename);
                } catch (\Exception $exception) {
                    echo $exception->getMessage();
                }
                $movie->setThumbnailPath($filePath);
            }

            $entityManager->flush();

            return $this->redirectToRoute('app_admin_movie_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('backend/admin/movie/edit.html.twig', [
            'movie' => $movie,
            'form' => $form,
            'pageTitle' => "Edit Movie",
        ]);
    }

    #[Route('/{id}', name: 'app_admin_movie_delete', methods: ['POST'])]
    public function delete(Request $request, Movie $movie, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $movie->getId(), $request->request->get('_token'))) {
            $entityManager->remove($movie);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_admin_movie_index', [], Response::HTTP_SEE_OTHER);
    }
}
