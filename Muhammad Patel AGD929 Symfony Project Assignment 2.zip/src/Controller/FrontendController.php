<?php

namespace App\Controller;

use App\Entity\Movie;
use App\Entity\MovieReview;
use App\Form\MovieReviewType;
use App\Repository\MovieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FrontendController extends AbstractController
{
    #[Route('/', name: 'app_index')]
    public function index(MovieRepository $movieRepository): Response
    {

        return $this->render('frontend/index.html.twig', [
            'movies' => $movieRepository->findAll(),
        ]);
    }

    #[Route('/movie/{id}/details', name: 'app_movie_details')]
    public function movieDetails(Request $request, EntityManagerInterface $entityManager, Movie $movie): Response
    {
        $movieReview = new MovieReview();
        $form = $this->createForm(MovieReviewType::class, $movieReview);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $movieReview->setMovie($movie);
            $movieReview->setUser($this->getUser());
            $entityManager->persist($movieReview);
            $entityManager->flush();

            $this->addFlash('success', 'Your review added successfully!');

            return $this->redirectToRoute('app_movie_details', [
                'id' => $movie->getId()
            ], Response::HTTP_SEE_OTHER);
        }

        return $this->render('frontend/movie_details.html.twig', [
            'movie' => $movie,
            'form' => $form,
        ]);
    }
}
