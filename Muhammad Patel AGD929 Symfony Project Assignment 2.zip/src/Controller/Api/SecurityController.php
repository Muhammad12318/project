<?php

namespace App\Controller\Api;

use Lexik\Bundle\JWTAuthenticationBundle\Security\Authenticator\Token\JWTPostAuthenticationToken;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\User\UserProviderInterface;

class SecurityController extends AbstractController
{
    #[Route(path: '/api/login_check', name: 'api_login_check', methods: ['POST'])]
    #[OA\RequestBody(
        content: new OA\MediaType(
            mediaType: "application/x-www-form-urlencoded",
            schema: new OA\Schema(
                properties: [
                    new OA\Property(property: 'username', type: 'string'),
                    new OA\Property(property: 'password', type: 'string'),
                ],
                type: 'object'
            )
        )
    )]
    #[OA\Response(
        response: 200,
        description: "OK"
    )]
    public function login(
        Request $request, UserProviderInterface $userProvider, JWTTokenManagerInterface $JWTManager, TokenStorageInterface $tokenStorage,
        UserPasswordHasherInterface $userPasswordHasher
    )
    {
        $username = $request->request->get('username');
        $password = $request->request->get('password');

        $user = $userProvider->loadUserByIdentifier($username);

        if (!$user || !$userPasswordHasher->isPasswordValid($user, $password)) {
            throw new AuthenticationException('Invalid credentials.');
        }

        $token = $JWTManager->create($user);
        $tokenStorage->setToken(new JWTPostAuthenticationToken($user, 'main', ['ROLE_ADMIN'], $token)); // Optionally store the token in the token storage

        return new JsonResponse(['token' => $token]);
    }

    #[Route("/logout", name: "app_logout")]
    public function logout(){

    }
}
