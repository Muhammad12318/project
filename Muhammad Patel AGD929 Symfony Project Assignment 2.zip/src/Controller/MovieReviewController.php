<?php

namespace App\Controller;

use App\Entity\MovieReview;
use App\Form\MovieReviewType;
use App\Repository\MovieReviewRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/dashboard/movie/review')]
#[IsGranted("ROLE_USER")]
class MovieReviewController extends AbstractController
{
    #[Route('/', name: 'app_movie_review_index', methods: ['GET'])]
    public function index(MovieReviewRepository $movieReviewRepository): Response
    {
        if ($this->getUser()->isAdmin()) {
            $movieReview = $movieReviewRepository->findAll();
        } else {
            $movieReview = $movieReviewRepository->findBy([
                'user' => $this->getUser()
            ]);
        }
        return $this->render('movie_review/index.html.twig', [
            'movie_reviews' => $movieReview,
            'pageTitle' => "Movies Reviews List",
//            'actionLink' => "app_movie_review_new",
        ]);
    }

    #[Route('/new', name: 'app_movie_review_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $movieReview = new MovieReview();
        $form = $this->createForm(MovieReviewType::class, $movieReview);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($movieReview);
            $entityManager->flush();

            return $this->redirectToRoute('app_movie_review_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('movie_review/new.html.twig', [
            'movie_review' => $movieReview,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_movie_review_show', methods: ['GET'])]
    public function show(MovieReview $movieReview): Response
    {

        return $this->render('movie_review/show.html.twig', [
            'movie_review' => $movieReview,
            'pageTitle' => "Reviews details",
        ]);
    }

    #[Route('/{id}/edit', name: 'app_movie_review_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, MovieReview $movieReview, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(MovieReviewType::class, $movieReview);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_movie_review_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('movie_review/edit.html.twig', [
            'movie_review' => $movieReview,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_movie_review_delete', methods: ['POST'])]
    public function delete(Request $request, MovieReview $movieReview, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $movieReview->getId(), $request->request->get('_token'))) {
            $entityManager->remove($movieReview);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_movie_review_index', [], Response::HTTP_SEE_OTHER);
    }
}
