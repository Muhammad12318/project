<?php

namespace App\Connector;

use GuzzleHttp\Client;

class OmdbApiConnector
{
    public function __construct(
        private $container
    ){}

    public function connect(): Client
    {
        return new Client([
            // Base URI is used with relative requests
            'base_uri' => $this->container->getParameter('OMDB_API_URL'),
        ]);
    }
}
