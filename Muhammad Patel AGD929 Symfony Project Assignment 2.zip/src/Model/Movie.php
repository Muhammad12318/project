<?php

namespace App\Model;

use App\Entity\User;
use Doctrine\DBAL\Types\Types;
use Symfony\Component\Serializer\Annotation\Groups;

class Movie
{
    public ?int $id = null;

    public ?string $title = null;

    public ?int $duration = null;

    public ?string $releaseYear = null;

    public ?string $genres = null;

    public ?string $casts = null;

    public ?string $description = null;

    public ?User $createdBy = null;


}
