We using lexik/jwt-authentication-bundle for token authentication
