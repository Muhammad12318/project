<?php

namespace App\Controller;

use App\Repository\MovieReviewRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route("user")]
class UserDashboardController extends AbstractController
{
    #[Route('/dashboard', name: 'app_user_dashboard')]
    public function index(MovieReviewRepository $movieReviewRepository): Response
    {
        $movieReview = null;
        if ($this->getUser()->isAdmin()) {
            $movieReview = $movieReviewRepository->findAll();
        } else {
            $movieReview = $movieReviewRepository->findBy([
                'user' => $this->getUser()
            ]);
        }

//        dd($movieReview);
        return $this->render('backend/admin/dashboard.html.twig', [
            'totalReviews' => $movieReview,
        ]);
    }
}
