<?php

namespace App\Controller;

use App\Entity\Movie;
use App\Form\MovieType;
use App\Repository\MovieRepository;
use App\Repository\MovieReviewRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\String\Slugger\SluggerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/movie')]
#[IsGranted("ROLE_ADMIN")]
class MovieAPIController extends AbstractController
{

    private $serializer;
    private $validator;

    public function __construct(SerializerInterface $serializer, ValidatorInterface $validator)
    {
        $this->serializer = $serializer;
        $this->validator = $validator;
    }

    #[Route('/list', name: 'api_movie_index', methods: ['GET'])]
    public function index(MovieRepository $movieRepository): JsonResponse
    {
        $movieReviews = $movieRepository->findAll();

        return $this->json($movieReviews, Response::HTTP_OK, [],
            [ObjectNormalizer::CIRCULAR_REFERENCE_HANDLER => function ($obj) {
                return $obj->getId();
            }]);
    }


    #[Route('/new', name: 'api_movie_new', methods: ['POST'])]
    public function create(Request $request, EntityManagerInterface $em, SluggerInterface $slugger): Response
    {
        // Deserialize the JSON part of the request
        $movieData = $request->getContent();
        if ($movieData) {
            $movie = $this->serializer->deserialize($movieData, Movie::class, 'json');
        } else {
            return new JsonResponse(['error' => 'Invalid movie data.'], Response::HTTP_BAD_REQUEST);
        }

        $movie->setThumbnailPath("movies_thumbnail/7885686-3-6572f7bad8181.png"); // Make sure your Movie entity has a setThumbnailPath method
        $movie->setCreatedBy($this->getUser());
        // Persist the Movie object
        $em->persist($movie);
        $em->flush();

        // Return the created Movie object in JSON format
        return $this->json($movie, Response::HTTP_CREATED);
    }


    #[Route('/show/{id}', name: 'api_movie_show', methods: ['GET'])]
    public function show($id, MovieRepository $repository): Response
    {
        $movie = $repository->find($id);

        if (!$movie) {
            return $this->json(['error' => 'Movie not found'], Response::HTTP_NOT_FOUND);
        }

        return $this->json($movie, context: ['groups' => ['movie']]);
    }

    #[Route('/edit/{id}', name: 'api_movie_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Movie $movie, EntityManagerInterface $em): Response
    {
        $updatedMovie = $this->serializer->deserialize($request->getContent(), Movie::class, 'json', ['object_to_populate' => $movie]);
        $em->flush();

        return $this->json($updatedMovie);
    }

    #[Route('/delete/{id}', name: 'api_movie_delete', methods: ['DELETE', 'POST'])]
    public function delete(Movie $movie, EntityManagerInterface $em): Response
    {
        $em->remove($movie);
        $em->flush();

        return $this->json(['status' => 'Deleted Successfully'], Response::HTTP_NO_CONTENT);
    }
}
