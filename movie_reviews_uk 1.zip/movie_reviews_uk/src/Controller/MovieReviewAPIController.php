<?php

namespace App\Controller;

use App\Entity\Movie;
use App\Entity\MovieReview;
use App\Repository\MovieRepository;
use App\Repository\MovieReviewRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;


#[Route('/api/movie/review')]
#[IsGranted("ROLE_USER")]
class MovieReviewAPIController extends AbstractController
{
    #[Route('/list', name: 'api_movie_review_index', methods: ['GET'])]
    public function index(MovieReviewRepository $movieReviewRepository): JsonResponse
    {
        $movieReviews = $movieReviewRepository->findAll();

        return $this->json($movieReviews,Response::HTTP_OK,[],
            [ObjectNormalizer::CIRCULAR_REFERENCE_HANDLER=>function ($obj){return $obj->getId();}]);
    }

    #[Route('/{movie_id}/new', name: 'api_movie_review_new', methods: ['POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, SerializerInterface $serializer,
                        ValidatorInterface $validator, Security $security, MovieRepository $movieRepository, int $movie_id): JsonResponse {
        $movieReviewData = $request->getContent();
        $movieReview = $serializer->deserialize($movieReviewData, MovieReview::class, 'json', ['groups' => ['review']]);

        // Validate the deserialized MovieReview
        $errors = $validator->validate($movieReview);
        if (count($errors) > 0) {
            $errorMessages = [];
            foreach ($errors as $error) {
                $errorMessages[] = $error->getMessage();
            }
            return $this->json(['errors' => $errorMessages], JsonResponse::HTTP_BAD_REQUEST);
        }

        // Fetch the associated Movie
        $movie = $movieRepository->find($movie_id);
        if (!$movie) {
            return $this->json(['message' => 'Movie not found'], JsonResponse::HTTP_NOT_FOUND);
        }

        // Associate the Movie with the MovieReview and set the User
        $movieReview->setMovie($movie);
        $user = $security->getUser(); // Assumes you have user authentication set up
        $movieReview->setUser($user);

        $entityManager->persist($movieReview);
        $entityManager->flush();

        // Specify the group when serializing your response
        return $this->json($movieReview, JsonResponse::HTTP_CREATED, [], ['groups' => ['review']]);
    }


    #[Route('/{id}', name: 'api_movie_review_show', methods: ['GET'])]
    public function show(MovieReview $movieReview): JsonResponse
    {
        return $this->json($movieReview);
    }

    #[Route('/{id}/edit', name: 'api_movie_review_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, MovieReview $movieReview, EntityManagerInterface $entityManager, SerializerInterface $serializer): JsonResponse {
        if ($request->getMethod() == 'POST') {
            $serializer->deserialize($request->getContent(), MovieReview::class, 'json', ['object_to_populate' => $movieReview, 'groups' => ['reviewEdit']]);
            $entityManager->flush();
        }

        return $this->json($movieReview, context: ['groups' => ['reviewEdit']]);
    }

    #[Route('/{id}', name: 'api_movie_review_delete', methods: ['DELETE', 'POST'])]
    public function delete(int $id, EntityManagerInterface $entityManager, MovieReviewRepository $movieReviewRepository): JsonResponse
    {
        // Manually fetch the MovieReview entity
        $movieReview = $movieReviewRepository->find($id);

        // If not found, return a custom JSON error response
        if (!$movieReview) {
            return $this->json(['message' => 'Movie review not found'], Response::HTTP_NOT_FOUND);
        }

        // Proceed to remove the MovieReview entity
        $entityManager->remove($movieReview);
        $entityManager->flush();

        // Since there's no content to return upon successful deletion, use HTTP status code 204 (No Content)
        return $this->json(['status' => 'Deleted Successfully'], Response::HTTP_NO_CONTENT);
    }
}
