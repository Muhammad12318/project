<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

class SecurityController extends AbstractController
{
    #[Route(path: '/api/login_check', name: 'api_login_check', methods: ['POST'])]
    public function login(Request $request, UserProviderInterface $userProvider, JWTTokenManagerInterface $JWTManager, TokenStorageInterface $tokenStorage)
    {
        $username = $request->request->get('username');
        $password = $request->request->get('password');

        $user = $userProvider->loadUserByUsername($username);

        if (!$user || !$this->passwordEncoder->isPasswordValid($user, $password)) {
            throw new AuthenticationException('Invalid credentials.');
        }

        $token = $JWTManager->create($user);
        $tokenStorage->setToken($token); // Optionally store the token in the token storage

        return new JsonResponse(['token' => $token]);
    }
}
