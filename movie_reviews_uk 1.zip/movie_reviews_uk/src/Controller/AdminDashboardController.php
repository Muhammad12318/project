<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\MovieRepository;
use App\Repository\MovieReviewRepository;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted("ROLE_ADMIN")]
#[Route("admin")]
class AdminDashboardController extends AbstractController
{
    #[Route('/dashboard', name: 'app_admin_dashboard')]
    public function index(UserRepository $userRepository, MovieRepository $movieRepository, MovieReviewRepository $movieReviewRepository): Response
    {

        if ($this->getUser()->isAdmin()) {
            $movieReviewRepository->findAll();
        } else {
            $movieReviewRepository->findBy($this->getUser()->getId());
        }

        return $this->render('backend/admin/dashboard.html.twig', [
            'pageTitle' => "Dashboard",
            'totalUsers' => $userRepository->findAll(),
            'totalMovies' => $movieRepository->findAll(),
            'totalReviews' => $movieReviewRepository->findAll(),
        ]);
    }

    #[Route('/movies', name: 'app_admin_movies')]
    public function movies(): Response
    {
        return $this->render('backend/admin/movies/index.html.twig', [
            'pageTitle' => "Movies List",
            'actionLink' => "app_admin_new_movie",
        ]);
    }

    #[Route('/movie/new', name: 'app_admin_new_movie')]
    public function newMovie(): Response
    {
        return $this->render('backend/admin/dashboard.html.twig', [
            'pageTitle' => "Movies",
            'actionLink' => "app_admin_new_movie",
        ]);
    }
}
