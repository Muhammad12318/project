package com.foodapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.foodapp.R
import com.foodapp.databinding.StartFragBinding
import com.foodapp.utils.AppUtils
import com.foodapp.utils.Constants

class StartFrag : Fragment(), View.OnClickListener {

    private var binding: StartFragBinding? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        AppUtils.statusBarBlackOrWhiteIcons(Constants.BLACK_STATUS_BAR, requireActivity().window)
        binding = StartFragBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
        clickListenersInit()
    }
    private fun init(){
        arguments?.let {
//            test = arguments?.getString("test")
        }
    }
    private fun clickListenersInit() {
        binding?.btnStart?.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when(v){
            binding?.btnStart->{
                this@StartFrag.findNavController().navigate(R.id.action_start_to_game_frag)
            }
        }
    }

    override fun onDestroyView() {
        binding = null
        super.onDestroyView()
    }


}