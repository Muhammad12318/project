package com.foodapp.utils


object Constants {

    const val WHITE_STATUS_BAR: String = "white"
    const val BLACK_STATUS_BAR: String = "black"


}