package com.foodapp.utils

import android.content.Context
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.View


class DragExperimentTouchListener(
    initialX: Float,
    initialY: Float,
    private val callback: (x: Float, y: Float) -> Unit
) :  View.OnTouchListener  {
    init {

    }

//    fun DragExperimentTouchListener() {
//        lastX = initalX
//        lastY = initialY
//    }

    var isDragging = false
    var lastX = initialX
    var lastY = initialY
    var deltaX = 0f

    override fun onTouch(view: View, arg1: MotionEvent): Boolean {
        val action = arg1.action
        if (action == MotionEvent.ACTION_DOWN && !isDragging) {
            isDragging = true
            deltaX = arg1.x
            return true
        } else if (isDragging) {
            when (action) {
                MotionEvent.ACTION_MOVE -> {
                    view.x = view.x + arg1.x - deltaX
                    view.y = view.y

                    callback(view.x,view.y)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    isDragging = false
                    lastX = arg1.x
                    lastY = arg1.y
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.x = lastX
                    view.y = lastY
                    isDragging = false
                    return true
                }
            }
        }
        return false
    }
}