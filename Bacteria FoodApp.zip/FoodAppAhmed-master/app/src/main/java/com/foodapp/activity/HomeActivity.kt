package com.foodapp.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.foodapp.databinding.HomeActivityBinding
import com.foodapp.utils.CommonDelegate
import com.foodapp.utils.CommonDelegateImpl

class HomeActivity : AppCompatActivity(), CommonDelegate by CommonDelegateImpl() {

    private var binding: HomeActivityBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setEdgeToEdgeLayout(window,this@HomeActivity)
        binding = HomeActivityBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        setHomeBottomMargin(binding?.homeRoot)

    }
    private fun setHomeBottomMargin(rootView: View?){
        rootView?.let {
            ViewCompat.setOnApplyWindowInsetsListener(it) { v: View, windowInsets: WindowInsetsCompat ->
                val insets: Insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
                val marginLayoutParams = v.layoutParams as ViewGroup.MarginLayoutParams
                marginLayoutParams.bottomMargin = insets.bottom
                v.layoutParams = marginLayoutParams
                WindowInsetsCompat.CONSUMED
            }
        }
    }
}