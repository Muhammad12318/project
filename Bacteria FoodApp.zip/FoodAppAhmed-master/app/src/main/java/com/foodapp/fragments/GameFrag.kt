package com.foodapp.fragments

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getMainExecutor
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import com.foodapp.R
import com.foodapp.databinding.GameFragBinding
import com.foodapp.utils.*
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import kotlin.concurrent.scheduleAtFixedRate


class GameFrag : Fragment(), View.OnClickListener {

    private var binding: GameFragBinding? = null
    private var arrImages = arrayListOf<Int>()
    private var arrLstQuots: Array<String>? = null
    private val timer = Timer("schedule", true)
    private var dataLst = arrayListOf<FoodItemModel>()
    private var isDialogOpen = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        AppUtils.statusBarBlackOrWhiteIcons(Constants.BLACK_STATUS_BAR, requireActivity().window)
        binding = GameFragBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
        clickListenersInit()
    }
    private fun init(){
        arguments?.let {
//            test = arguments?.getString("test")
        }
        arrLstQuots =  requireContext().resources.getStringArray(R.array.gravityArray)
        binding?.tvProgress?.text = "50%"
            makeDataList()
        binding?.progress?.progressDrawable?.setColorFilter(Color.GREEN, android.graphics.PorterDuff.Mode.SRC_IN)
        startGame()


    }
    private fun clickListenersInit() {
        binding?.touchDisableOverlay?.setOnClickListener {}
        binding?.imgPlayer?.setOnTouchListener(DragExperimentTouchListener(
            binding?.imgPlayer?.x?:0f,
            binding?.imgPlayer?.y?:0f
        ) { x, y -> onDragCallBack(x, y) })
        binding?.rootContainer?.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val x = event.x.toInt()  // get x-Coordinate
                val y = event.y.toInt()
                if (y >= 1700){
                    return@setOnTouchListener false
                }
               // get y-Coordinate
                val lp = RelativeLayout.LayoutParams(200, 200) // Assuming you use a RelativeLayout
                val img = ImageView(requireContext())
                lp.setMargins(x-100, y-100, 0, 0) // set margins
                img.layoutParams = lp
                val foodItem = dataLst.random()
                img.setImageDrawable(ContextCompat.getDrawable(requireContext(),(foodItem.img)))
                img.tag = foodItem
                (view as ViewGroup).addView(img) // add a View programmatically to the ViewGroup
                val  value = binding?.rootContainer?.bottom?.minus(y)?.minus(binding?.cV?.bottom?:0)?.minus(300)
                ObjectAnimator.ofFloat(img, "translationY",value?.toFloat()?:0f).apply {
                    duration = 3000
                    start()
                }.addListener(object : AnimatorListenerAdapter(){
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        if(binding?.imgPlayer?.isOverlap(img) == true){
                           val item  = img.tag as FoodItemModel
//                            Handler(Looper.getMainLooper()).postDelayed({
//                                binding?.tvQuote?.visibility = View.INVISIBLE
//                            }, 2000)
                            binding?.tvQuote?.text = item.quote
                            binding?.tvQuote?.visibility = View.VISIBLE
                            if (item != null){
                                when(item.type){
                                    0->{
                                        if (binding?.progress?.progress!! >= 100){
                                            binding?.progress?.progress = 100
                                            binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                            timer.cancel()
                                            if (!isDialogOpen){
                                                showDialog("Game Over You Lose")
                                            }

                                        }else{
                                            var progressValue = binding?.progress?.progress
                                            if (progressValue!! <= 0){
                                                binding?.progress?.progress = progressValue
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                                timer.cancel()
                                                if (!isDialogOpen){
                                                    showDialog("Game Over You Lose")
                                                }
                                                return
                                            }
                                            if (progressValue !=0){
                                                progressValue= progressValue!!-10
                                            }
                                            if (progressValue >= 100){
                                                binding?.progress?.progress = 100
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                                timer.cancel()
                                                if (!isDialogOpen){
                                                    showDialog("Game Over You Lose")
                                                }
                                            }else{
                                                if (progressValue!! <= 0){
                                                    binding?.progress?.progress = progressValue
                                                    binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                                    timer.cancel()
                                                    if (!isDialogOpen){
                                                        showDialog("Game Over You Lose")
                                                    }
                                                    binding?.rootContainer?.removeView(img)
                                                    return
                                                }
                                                binding?.progress?.progress = progressValue
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                            }

                                        }
                                    }
                                    1->{
                                        if (binding?.progress?.progress!! >= 100){
                                            binding?.progress?.progress = 100
                                            binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                            timer.cancel()
                                            if (!isDialogOpen){
                                                showDialog("You Have Won")
                                            }
                                        }else{
                                            var progressValue = binding?.progress?.progress
                                            if (progressValue!! <= 0){
                                                binding?.progress?.progress = progressValue
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                                timer.cancel()
                                                if (!isDialogOpen){
                                                    showDialog("You Have Won")
                                                }
                                                binding?.rootContainer?.removeView(img)
                                                return
                                            }

                                            progressValue= progressValue!!+10
                                            if (progressValue >= 100){
                                                binding?.progress?.progress = 100
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                                timer.cancel()
                                                if (!isDialogOpen){
                                                    showDialog("You Have Won")
                                                }
                                            }else{
                                                binding?.progress?.progress = progressValue
                                                binding?.tvProgress?.text = "${binding?.progress?.progress}%"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        binding?.rootContainer?.removeView(img)
//                        img.setOnClickListener(this@GameFrag)
                    }
                })
            }
            true
        }
    }
    private fun onDragCallBack(x:Float ,y:Float ){
        Log.v("kashif","x = ${x}")
        Log.v("kashif","y = ${y}")
//       if(binding?.imgPlayer?.isOverlap(binding?.dummy) == true){
//           Toast.makeText(requireContext(), "i am touched", Toast.LENGTH_SHORT).show()
//       }
    }
    override fun onClick(v: View?) {
        binding?.rootContainer?.removeView(v)
//        showDialog()
    }

    private fun startGame(){
        val defaultDisplay = getSystemService(requireContext(),DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
        timer.scheduleAtFixedRate(2000,2000) {
            MainScope().launch {
                withContext(Dispatchers.Main) {
                    val randumNumber = (0..defaultDisplay?.width!!-200).random()

                    binding?.rootContainer?.dispatchTouchEvent(MotionEvent.obtain(0,0,MotionEvent.ACTION_DOWN, randumNumber.toFloat(),100f,0.5f,5f,99,1f,1f,0,0))
                }
            }
        }
    }
    private fun showDialog(msg: String ){
        isDialogOpen = true
        MaterialAlertDialogBuilder(requireContext())
//            .setTitle(arrGravity?.random())
            .setCancelable(false)
            .setTitle(msg)
//            .setMessage(arrLstQuots?.random())
            .setPositiveButton("Restart Game")
            { dialogInterface, i ->
                requireActivity().supportFragmentManager.popBackStack()
                dialogInterface.dismiss()
            }
            .show()
    }

    private fun makeDataList(){
        val foo1 = FoodItemModel(R.drawable.burger,"Burger",0,"Bacteria are amongst the smallest living things in the world, containing just one cell.")
        val foo2 = FoodItemModel(R.drawable.apple,"Apple",1,"Bacteria are so small that we need a microscope in order to see them.")
        val foo3 = FoodItemModel(R.drawable.pizza,"Pizza",0,"Bacteria can be found everywhere, including in the air, on our skin, on the ground, in our bodies, and in nature.")
        val foo5 = FoodItemModel(R.drawable.sandwitch,"Sandwich",0,"Bacteria are microorganisms which need nutrition from their environment.")
        val foo6 = FoodItemModel(R.drawable.banana,"Banana",1,"There are many different types that come in various shapes and sizes, including spheres, spirals, and rods")
        val foo7 = FoodItemModel(R.drawable.orange,"Orange",1,"Most bacteria are not dangerous, though there are some kinds of bacteria that can make us sick. Bacteria that make us sick are called pathogens.")
        val foo8 = FoodItemModel(R.drawable.bacteria1,"Bacteria1",0,"Our bodies can fight off pathogens with our immune system, but in the process, we can get sick. We can prevent pathogens from entering our bodies by washing our hands.")
        val foo9 = FoodItemModel(R.drawable.bacteria2,"Bacteria2",0,"Different bacteria can survive in a variety of extreme conditions. From ice to hot springs, and even radioactive waste.")
        val foo10 = FoodItemModel(R.drawable.bacteria3,"Bacteria3",0,"Bacteria are so small that we need a microscope in order to see them.\n")
        dataLst.add(foo1)
        dataLst.add(foo2)
        dataLst.add(foo3)
//        dataLst.add(foo4)
        dataLst.add(foo5)
        dataLst.add(foo6)
        dataLst.add(foo7)
        dataLst.add(foo8)
        dataLst.add(foo9)
        dataLst.add(foo10)
    }

    override fun onDestroyView() {
        binding = null
        super.onDestroyView()
        timer.cancel()
    }
}