package com.foodapp.utils

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.view.Window
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.foodapp.R

class CommonDelegateImpl: CommonDelegate {

    override fun setEdgeToEdgeLayout(window: Window?, context: Context) {
       window?.let {
           WindowCompat.setDecorFitsSystemWindows(window, false)
           if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
               window.statusBarColor = ContextCompat.getColor(context, R.color.transparent)
               window.navigationBarColor = ContextCompat.getColor(context, R.color.black)
           } else {
               window.statusBarColor = Color.TRANSPARENT
           }
       }
    }

//    override fun setStatusBarBlackOrWhiteIcons(color: String,window: Window) {
//        when(color){
//            Constants.BLACK_STATUS_BAR->{
//                val insetsControllerCompat = WindowInsetsControllerCompat(window, window.decorView)
//                insetsControllerCompat.isAppearanceLightStatusBars = true
//            }
//            Constants.WHITE_STATUS_BAR->{
//                val insetsControllerCompat = WindowInsetsControllerCompat(window, window.decorView)
//                insetsControllerCompat.isAppearanceLightStatusBars = false
//            }
//        }
//    }

}

interface CommonDelegate {

    fun setEdgeToEdgeLayout(window: Window?, context: Context)

//    fun setStatusBarBlackOrWhiteIcons(color: String,window: Window)

}