package com.foodapp.utils

data class FoodItemModel(val img: Int,val name: String,val type: Int,val quote: String)
