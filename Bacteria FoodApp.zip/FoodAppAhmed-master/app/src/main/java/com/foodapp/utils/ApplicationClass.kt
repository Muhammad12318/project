package com.foodapp.utils

import android.app.Application

class ApplicationClass  : Application(){
    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: ApplicationClass
            private set
    }
}