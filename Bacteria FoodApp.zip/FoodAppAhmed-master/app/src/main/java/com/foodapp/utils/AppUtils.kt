package com.foodapp.utils

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.*
import android.view.inputmethod.InputMethodManager
import androidx.core.view.WindowInsetsControllerCompat


object AppUtils {

        fun savePreferenceValue(key: String, value: Any?){
            val sharedPref = ApplicationClass.instance.applicationContext.getSharedPreferences(
                ApplicationClass.instance.applicationContext.packageName, Context.MODE_PRIVATE)?: return
            if (value == null){return}
            with(sharedPref.edit()) {
                when(value){
                    is String -> {
                        putString(key, value)
                    }
                    is Boolean -> {
                        putBoolean(key, value)
                    }
                    is Int -> {
                        putInt(key, value)
                    }
//                    is Double -> {
//                        putLong(key, java.lang.Double.doubleToRawLongBits(value))
//                    }
                }
                apply()
            }
        }

        fun getPreferenceValue(key: String, defaultValue: Any): Any{
            val sharedPref = ApplicationClass.instance.applicationContext.getSharedPreferences(
                ApplicationClass.instance.applicationContext.packageName, Context.MODE_PRIVATE)
            lateinit var value: Any

            when(defaultValue){
                is String -> {
                    value = sharedPref?.getString(key, defaultValue) ?: ""
                }
                is Boolean -> {
                    value = sharedPref?.getBoolean(key, defaultValue) ?: false
                }
                is Int -> {
                    value = sharedPref?.getInt(key, defaultValue) ?: 0
                }
//                is Long -> {
//                    value = sharedPref?.getLong(key, defaultValue) ?: 0.0
//                }
            }
            return value
        }
//

        fun hideKeyboard(view: View?) {
            val imm = view?.context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }



    fun parseStringColor(colorString: String?): Int {
        var colorString = colorString
        if (colorString != null) {
            if (!colorString.startsWith("#"))
                colorString = "#$colorString"
            try {
                return Color.parseColor(colorString.trim { it <= ' ' })
            } catch (numberFormatException: NumberFormatException) {
                return 0
            } catch (parseException: IllegalArgumentException) {
                return 0
            }

        }
        return 0
    }

    fun returnHexCode(colorString: String?):String{
        var colorString = colorString
        if (colorString != null) {
            if (!colorString.startsWith("#"))
                colorString = "#$colorString"
        }
        return colorString?:"#ffffff"
    }

    fun manipulateColor(color: Int, factor: Float): Int {
        val a = Color.alpha(color)
        val r = Math.round(Color.red(color) * factor)
        val g = Math.round(Color.green(color) * factor)
        val b = Math.round(Color.blue(color) * factor)
        return Color.argb(a,
            Math.min(r, 255),
            Math.min(g, 255),
            Math.min(b, 255))
    }
    fun getSystemStatusBarSize(context: Context): Int {
        var pixelSize = 0
        val resId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resId > 0) {
            pixelSize = context.resources.getDimensionPixelSize(resId)
        }
        return pixelSize
    }
    fun setCustomTopMargin(view: View?) {
        if (getSystemStatusBarSize(ApplicationClass.instance.applicationContext) ?: 0 > 0) {
            if (view?.getLayoutParams() is ViewGroup.MarginLayoutParams) {
                val p: ViewGroup.MarginLayoutParams = view.getLayoutParams() as ViewGroup.MarginLayoutParams
                p.setMargins(0, getSystemStatusBarSize(ApplicationClass.instance.applicationContext) ?: 0, 0, 0)
                view.requestLayout()
            }
        }
    }
     fun statusBarBlackOrWhiteIcons(color: String,window: Window) {
        when(color){
            Constants.BLACK_STATUS_BAR ->{
                val insetsControllerCompat = WindowInsetsControllerCompat(window, window.decorView)
                insetsControllerCompat.isAppearanceLightStatusBars = true
            }
            Constants.WHITE_STATUS_BAR ->{
                val insetsControllerCompat = WindowInsetsControllerCompat(window, window.decorView)
                insetsControllerCompat.isAppearanceLightStatusBars = false
            }
        }
    }

}

fun Int.dpToPx(displayMetrics: DisplayMetrics): Int = (this * displayMetrics.density).toInt()
fun Int.pxToDp(displayMetrics: DisplayMetrics): Int = (this / displayMetrics.density).toInt()

fun View.isOverlap(other: View?, deltaX: Int = 0, deltaY: Int = 0): Boolean {
    val thisXY  = IntArray(2).apply { getLocationOnScreen(this) }
    val otherXY = IntArray(2).apply {
        other?.getLocationOnScreen(this)
        this[0] += deltaX
        this[1] += deltaY
    }
    return thisXY.let { Rect(it[0], it[1], it[0] + width, it[1] + height) }
        .intersect(otherXY.let {
            Rect(it[0], it[1], it[0] + other?.width!!, it[1] + other.height)
        })
}