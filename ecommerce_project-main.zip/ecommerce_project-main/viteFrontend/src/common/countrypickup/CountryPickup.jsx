import React, { useState } from 'react';
import { Country, State, City }  from 'country-state-city';
import { Grid } from '@mui/material';


const CountryPickup = ({countrySetter = ()=>{}, citySetter=()=>{}, stateSetter=()=>{}, cityRef = null, countryRef = null, stateRef = null}) => {

  const [country, setCountry] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");


  const [countries, setCountries] = useState(Country.getAllCountries());
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);


  const onCountySelect = (e)=>{
    let value = e.target.value;
    setCountry(value);
    setStates(State.getStatesOfCountry(value));
    countrySetter(Country.getCountryByCode(value)?.name);
    stateSetter("");
    citySetter("");
    setState("");
    setCity("");
  }

  const onStateSelect = (e)=>{
    let value = e.target.value;
    setState(value);
    setCities(City.getCitiesOfState(country, value));
    stateSetter(State.getStateByCodeAndCountry(value, country)?.name);
    citySetter("");
    setCity("");
  }

  const onCitySelect = (e)=>{
    let value = e.target.value;
    setCity(value);
    citySetter(value);
  }

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xl={4} lg={4} md={4} sm={12} xs={12}>
            <p className="input-heading">Country</p>
            <select className='input' value={country} onChange={onCountySelect} ref={countryRef}>
              <option value=""></option>
              {
                countries.map((el, i)=><option key={i} value={el.isoCode}>{el.name}</option>)
              }
            </select>
        </Grid>
        <Grid item xl={4} lg={4} md={4} sm={12} xs={12}>
            <p className="input-heading">State</p>
            <select className='input' value={state} onChange={onStateSelect} ref={stateRef}>
              <option value=""></option>
              {
                states.map((el, i)=><option key={i} value={el.isoCode}>{el.name}</option>)
              }
            </select>
        </Grid>
        <Grid item xl={4} lg={4} md={4} sm={12} xs={12}>
            <p className="input-heading">City</p>
            <select className='input' value={city} onChange={onCitySelect} ref={cityRef}>
              <option value=""></option>
              {
                cities.map((el, i)=><option key={i} value={el.name}>{el.name}</option>)
              }
            </select>
        </Grid>

      </Grid>
    </>
  )
}

export default CountryPickup;
