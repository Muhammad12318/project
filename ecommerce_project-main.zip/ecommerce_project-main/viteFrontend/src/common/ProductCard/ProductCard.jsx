import React from 'react'
import { Box, Typography } from '@mui/material'
import NotFound from "../../assets/img/not-found.png";

const ProductCard = ({ name = "name", img = null, price = "0000", description = "Description", fullWidth }) => {
    return (
        <>
            <Box sx={{ width: fullWidth ? "100%" : "200px" }}>
                <img
                    className='productImage'
                    src={img}
                    style={{width: fullWidth? "100%": "200px"}}
                    alt="Fashion product"
                    onError={(e) => {
                        e.target.src = NotFound;
                    }}
                />
                <div className='productDetailContainer'>
                    <Typography sx={{ fontWeight: "bold", mb: 0.3 }} className='productName'>
                        {name}
                    </Typography>
                    <Typography variant='h6' sx={{ fontWeight: "bolder", mb: 0.3, fontFamily: "Times New Roman" }} className='productPrice'>
                        $ {price}
                    </Typography>
                    <Typography variant='subtitle2'>
                        {description.length <= 80 ? description : (description.substr(0, 80) + "...")}
                    </Typography>
                </div>
            </Box>
        </>
    )
}

export default ProductCard
