import { createTheme } from "@mui/material/styles";

const THEME = createTheme({
    typography: {
     "fontFamily": `'Work Sans', sans-serif`,
     "fontSize": 14,
     "fontWeightLight": 300,
     "fontWeightRegular": 400,
     "fontWeightMedium": 500
    },
    // components: {
    //     MuiAppBar: {
    //         styleOverrides: {
    //             root: {
    //             }
    //         }
    //     },
    // },
    palette: {
        primary:{
            main: "#4a044e"
        }
    },
    darkBlue: "#4a044e"
});

export default THEME;