import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Typography,
  Paper,
  Container,
  Button,
  TextField,
  Grid,
  ButtonBase,
  FormControlLabel,
  FormControl,
  FormLabel,
  Radio,
  RadioGroup,
} from "@mui/material";
import { LoadingButton } from "@mui/lab";
import { BiListPlus } from "react-icons/bi";
import { BsPlus } from "react-icons/bs";
import Modal from "../../components/modal/Modal";
import { useAlert } from "react-alert";
import { postProduct, getUserProducts } from "../../redux/slices/product";
import ProductCard from "../../common/ProductCard/ProductCard";
import getMediaEndPoint from "../../utils/getEndPointForMedia";
const Sell = () => {
  const alert = useAlert();
  const dispatch = useDispatch();
  let promise = null;
  const loading = useSelector((state) => state.product.loading);
  const [uploadModal, setUploadModal] = useState(false);
  const [imgUrl, setImgUrl] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [details, setDetails] = useState({
    images: [],
    name: "",
    description: "",
    price: 1,
    minimumOrderQuantity: 1,
    location: "",
    condition: "",
    keywords: [],
    availability: false,
  });

  useEffect(() => {
    if (!uploadModal) {
      let promise = dispatch(getUserProducts());
      promise.unwrap().then((res) => {
        if (res.statusCode === 200) {
          setAllProducts(res.data);
        }
      });
    }
  }, [uploadModal]);

  const toggleUploadModal = () => setUploadModal(!uploadModal);

  const inputField = {
    margin: "10px 0px",
  };

  const handleInputs = (e) => {
    let name = e.target.name,
      value = e.target.value;
    setDetails({ ...details, [name]: value });
  };

  const handleImageUpload = async (event, index = 0) => {
    const file = event.target.files[0];
    let productDetails = { ...details };
    const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
    if (!isJpgOrPng) {
      alert.error("You can only upload JPG/PNG file!");
      return;
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      alert.error("Image must smaller than 2MB!");
      return;
    }
    productDetails.images[index] = file;
    setDetails(productDetails);

    let imagesUri = [...imgUrl];
    imagesUri[index] = await getBase64(file);
    setImgUrl(imagesUri);
  };

  const getBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const onSubmit = (event) => {
    event.preventDefault();

    promise?.abort();

    if (!details.name) {
      alert.error("Product name is required!");
      return;
    }
    if (!details.description) {
      alert.error("Product description is required!");
      return;
    }
    if (!details.availability) {
      alert.error("Product availablity is required!");
      return;
    }

    if (details.images?.length < 3) {
      alert.error("At least 3 Product images are required!");
      return;
    }

    let formData = new FormData();
    for (const image of details.images) {
      formData.append("images", image);
    }
    formData.append("name", details.name);
    formData.append("description", details.description);
    formData.append("price", details.price);
    formData.append("minimumOrderQuantity", details.minimumOrderQuantity);
    formData.append("location", details.location);
    formData.append("keywords", [details.keywords]);
    formData.append("condition", details.condition);
    formData.append("availability", details.availability);

    promise = dispatch(postProduct(formData));
    promise.unwrap().then((response) => {
      alert.info(response?.msg);
      if (response.statusCode === 200) {
        toggleUploadModal();
      }
    });
  };
  return (
    <section id="Sell">
      <Modal
        fullScreen
        open={uploadModal}
        onClose={toggleUploadModal}
        title="Upload Product"
      >
        <Grid container spacing={2} columns={15}>
          {new Array(5).fill(3).map((el, i) => (
            <Grid key={i} item xs={15} sm={3} lg={3} xl={3}>
              <input
                type="file"
                id={`productImg${i}`}
                hidden
                onChange={(e) => handleImageUpload(e, i)}
              />
              <ButtonBase
                sx={{ width: "100%" }}
                onClick={() =>
                  document.getElementById(`productImg${i}`).click()
                }
              >
                {imgUrl[i] ? (
                  <Box sx={{ py: 1 }} border="1px dashed #9e9e9e" flexGrow={1}>
                    <img
                      src={imgUrl[i]}
                      width="100%"
                      height="115px"
                      style={{ objectFit: "contain" }}
                      alt="product image"
                    />
                    <Typography color="#9e9e9e">
                      {" "}
                      {details.images?.[i]?.name}{" "}
                    </Typography>
                  </Box>
                ) : (
                  <Box
                    sx={{ py: 6 }}
                    flexGrow={1}
                    border="1px dashed #9e9e9e"
                    display="flex"
                    flexDirection="column"
                    justifyContent="center"
                    alignItems="center"
                  >
                    <Typography>
                      {" "}
                      <BsPlus size={30} color="#9e9e9e" />{" "}
                    </Typography>
                    <Typography color="#9e9e9e"> Upload Image </Typography>
                  </Box>
                )}
              </ButtonBase>
            </Grid>
          ))}
        </Grid>
        <form onSubmit={onSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="text"
                variant="filled"
                label="Name"
                name="name"
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="number"
                variant="filled"
                label="Price"
                name="price"
                inputProps={{
                  inputMode: "numeric",
                  pattern: "[0-9]*",
                  min: Number(details.minimumPrice) + 1,
                }}
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="text"
                variant="filled"
                label="Location"
                name="location"
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="number"
                variant="filled"
                label="Minimum Order Quantity"
                name="minimumOrderQuantity"
                inputProps={{
                  inputMode: "numeric",
                  pattern: "[0-9]*",
                  min: "1",
                }}
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="text"
                variant="filled"
                label="Keywords"
                name="keywords"
                placeholder="Enter keywords with comma separeted"
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <FormControl required>
                <FormLabel> Condition </FormLabel>
                <RadioGroup
                  row
                  name="condition"
                  value={details.condition}
                  onChange={handleInputs}
                >
                  <FormControlLabel
                    control={<Radio value={"new"} />}
                    label="New"
                  />
                  <FormControlLabel
                    control={<Radio value={"used"} />}
                    label="Used"
                  />
                </RadioGroup>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <TextField
                type="text"
                variant="filled"
                label="Description"
                name="description"
                multiline
                rows={10}
                fullWidth
                sx={inputField}
                onChange={handleInputs}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <FormControl required>
                <FormLabel> Availability </FormLabel>
                <RadioGroup
                  name="availability"
                  value={details.availability}
                  onChange={handleInputs}
                >
                  <FormControlLabel
                    control={<Radio value={true} />}
                    label="In Stock"
                  />
                  <FormControlLabel
                    control={<Radio value={false} />}
                    label="Out of Stock"
                  />
                </RadioGroup>
              </FormControl>
            </Grid>
          </Grid>
          <LoadingButton loading={loading} variant="contained" type="submit">
            {" "}
            Submit{" "}
          </LoadingButton>
        </form>
      </Modal>
      <Container sx={{ mt: 3 }}>
        <Paper elevation={3} sx={{ p: 3 }}>
          <Box display="flex" justifyContent="space-between" sx={{ mb: 2 }}>
            <Typography variant="h5">Your Products</Typography>
            <Button
              variant="contained"
              color="warning"
              startIcon={<BiListPlus />}
              onClick={toggleUploadModal}
            >
              Upload
            </Button>
          </Box>
          <Box>
            <Grid container>
              {allProducts.map((el, i) => (
                <Grid key={i} item xs={12} sm={6} lg={3}>
                  <ProductCard
                    {...el}
                    productCode={el.id}
                    img={`${getMediaEndPoint()}/images/${el.images[0]}`}
                  />
                </Grid>
              ))}
            </Grid>
          </Box>
        </Paper>
      </Container>
    </section >
  );
};

export default Sell;
