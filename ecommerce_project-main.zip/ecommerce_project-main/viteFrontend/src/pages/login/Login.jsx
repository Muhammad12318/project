import React, { useState } from 'react';
import { Paper, TextField, Box, Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { login } from "../../redux/slices/user";
import { useAlert } from 'react-alert';
import { FaLock, FaEnvelope } from "react-icons/fa"
import "./Login.css";

const Login = () => {

  var promise = null;
  const dispach = useDispatch();
  const navigate = useNavigate()
  const alert = useAlert();
  const loading = useSelector(state => state.user.loading);
  const userData = useSelector(state => state.user.data);
  const [details, setDetails] = useState({
    email: "",
    password: "",
  })

  const inputField = {
    margin: "10px 0px",
  }


  const handleInputs = (event) => {
    let name = event.target.name, value = event.target.value;
    setDetails({ ...details, [name]: value });
  }

  const handleLogin = () => {
    promise?.abort();
    if (!details.email || !details.password) {
      return alert.error("Email or Password is required!")
    }
    promise = dispach(login(details));
    promise.unwrap()
      .then((response) => {
        alert.info(response.msg);
        if(response.statusCode === 200){
          navigate("/");
        }
      })
  }
  return (
    <section id="login">
      {
        userData?.role &&
        <Navigate to="/" />
      }
      <Paper elevation={3} sx={{ width: { xs: "90%", sm: "400px", md: "600px" }, p: 3 }}>
        <Typography variant='h3' color="var(--theme-color)">
          Login
        </Typography>
        <Typography variant='caption'>
          Welcome Back! Good to see you again.
        </Typography>
        <TextField
          type="email"
          variant="outlined"
          label="Email"
          name="email"
          fullWidth
          sx={inputField}
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaEnvelope color='var(--theme-color)' style={{ marginRight: "5px" }} />,
          }}
          required
        />
        <TextField
          type="password"
          variant="outlined"
          label="Password"
          name="password"
          fullWidth
          sx={inputField}
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaLock color='var(--theme-color)' style={{ marginRight: "5px" }} />
          }}
          required
        />
        <Typography variant='caption' display="flex" justifyContent="flex-end">
          <Link to="/forgot-password"> Forgot Password </Link>
        </Typography>
        <Typography variant='caption' display="flex" justifyContent="flex-end">
          <Link to="/signup"> Does not have an account! SignUp </Link>
        </Typography> <br /><br />
        <Box display="flex" justifyContent={"center"} paddingX="20%">
          <LoadingButton loading={loading} variant='contained' fullWidth onClick={handleLogin} sx={{ color: "white" }}>
            Login
          </LoadingButton>
        </Box>
      </Paper>
    </section>
  )
}

export default Login
