import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { getSearchProducts } from '../../redux/slices/product';
import { Box, Container, Grid } from '@mui/material';
import ProductCard from '../../common/ProductCard/ProductCard';
import getMediaEndPoint from '../../utils/getEndPointForMedia';
import Searchbar from './Searchbar';
import "./SearchProduct.scss"
import { Space, Spin } from 'antd';

const SearchProducts = () => {


    const dispatch = useDispatch();
    const {searchResults, loading} = useSelector(state => state.product);

    useEffect(() => {
        handleSearcchProducts({ search: "", sort: {_id: -1} });
    }, []);


    const handleSearcchProducts = (data) => {
        dispatch(getSearchProducts(data))
    }

    return (
        <Container>
            <br />
            <br />
            <Searchbar searchTeams={handleSearcchProducts} />
            <br />
            <br />
            <Box sx={{backgroundColor: "white", p: 3, minHeight: "70vh"}}>
                <Grid container spacing={2}>
                    {
                        loading ?
                        <Space align='center' style={{width: "100%", justifyContent: "center", paddingTop: "40px"}}>
                            <Spin size='large' tip="Searching Results" />
                        </Space>
                        :
                        searchResults?.map((el, i) => (
                            <Grid item xs={12} sm={6} md={3} lg={3}>
                                <ProductCard
                                    fullWidth
                                    img={`${getMediaEndPoint()}/images/${el.images[0]}`}
                                    {...el}
                                />
                            </Grid>
                        ))
                    }
                </Grid>
            </Box>
        </Container>
    )
}

export default SearchProducts
