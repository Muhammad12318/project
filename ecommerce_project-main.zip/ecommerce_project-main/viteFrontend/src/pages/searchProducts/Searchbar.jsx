import React from 'react'
import { useState } from 'react';
// MUI | ANT-D :
import { Dropdown, Input, Select, Form } from 'antd'
// ICONS
import FilterListOutlinedIcon from '@mui/icons-material/FilterListOutlined';
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';
import SearchIcon from '@mui/icons-material/Search'
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';
import AddOutlined from '@mui/icons-material/AddOutlined';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';

function Searchbar({ searchTeams }) {

    const [selectedSort, setSelectedSort] = useState("The newest");
    const [viewFilters, setViewFilters] = useState(false);

    const handleSortMenuClick = (e) => {
        setSelectedSort(e.key);
    }

    const handleSubmit = (data) => {
        let sortValue = {};
        // will test is it working?
        switch (selectedSort) {
            case "The newest":
                sortValue._id = -1;
                break;
            case "Highest Price":
                sortValue.price = -1;
                break;
            case "Lowest Price":
                sortValue.price = 1;
                break;
        }

        if (searchTeams) {
            searchTeams({ ...data, sort: sortValue })
        }
    }

    return (
        <div className="search-bar-wrapper">
            <Form onFinish={handleSubmit}>
                <div className="search-bar-container">
                    <div className="search-bar-item">
                        <div className='body'>
                            <div className="label">
                                <p> Search for Teams </p>
                            </div>
                            <div className="content">
                                <Form.Item name="search" rules={[{ required: true, message: "Search Keyword is required!" }]} rootClassName='search'>
                                    <Input type="search" placeholder='Search...' size='large' />
                                </Form.Item>
                            </div>
                        </div>
                    </div>
                    <div className="search-bar-item">
                        <div className="icon">
                            <FilterListOutlinedIcon />
                        </div>
                        <div className='body'>
                            <div className="label">
                                <p> Sort By </p>
                            </div>
                            <div className="content">
                                <Dropdown
                                    trigger={["click"]}
                                    rootClassName='sort-dropdown'
                                    menu={{
                                        onClick: handleSortMenuClick,
                                        items: [
                                            {
                                                label: "The newest",
                                                key: "The newest",
                                            },
                                            {
                                                label: "Highest Price",
                                                key: "Highest Price",
                                            },
                                            {
                                                label: "Lowest Price",
                                                key: "Lowest Price",
                                            },
                                        ]
                                    }}
                                >
                                    <div className='sort-selector'>
                                        <div className="selected-item">
                                            {selectedSort}
                                        </div>
                                        <div className="dropdown-arrow">
                                            <ExpandMoreOutlinedIcon />
                                        </div>
                                    </div>
                                </Dropdown>
                            </div>
                        </div>
                    </div>
                    <div className="search-bar-item">
                        <div className="icon">
                            <FilterAltOutlinedIcon />
                        </div>
                        <div className='body'>
                            <div className="label">
                                <p> Filters </p>
                            </div>
                            <div className="content">
                                <div className='filter-selector'>
                                    <div className={`filter-item${viewFilters ? "-close" : ""}`} onClick={() => setViewFilters(!viewFilters)}>
                                        {
                                            viewFilters ?
                                                "Remove Filters" :
                                                "View All Filters"
                                        }
                                    </div>
                                    <div className={`filter-arrow${viewFilters ? "-close" : ""}`} onClick={() => setViewFilters(!viewFilters)}>
                                        {
                                            viewFilters ?
                                                <CloseOutlinedIcon />
                                                :
                                                <AddOutlined />
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='icon'>
                            <button type='submit'>
                                <SearchIcon fontSize="large" />
                            </button>
                        </div>
                    </div>
                </div>
                {
                    viewFilters &&
                    <div className='filters-container'>
                        <div className="filter-item">
                            <div className="icon">
                                <p> Filter by </p>
                            </div>
                        </div>
                        <div className="filter-item">
                            <div className="body">
                                <Form.Item name="price" label="Price">
                                    <Input type='number' min="1" placeholder='Enter Max Price' size='large' />
                                </Form.Item>
                            </div>
                        </div>
                    </div>
                }
            </Form>
        </div>
    )
}

export default Searchbar
