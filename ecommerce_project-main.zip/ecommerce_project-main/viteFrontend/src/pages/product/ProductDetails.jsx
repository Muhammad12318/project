import React, { useEffect, useState } from 'react';
import { Box, Chip, Container, Grid, Tab, Tabs, TextField, Typography } from '@mui/material';
import { Button } from 'antd';
import CartIcon from "@mui/icons-material/ShoppingCart"
import PropTypes from 'prop-types';
import AirportShuttleIcon from '@mui/icons-material/AirportShuttle';
import CachedIcon from '@mui/icons-material/Cached';
import ThumbUpOffAltIcon from '@mui/icons-material/ThumbUpOffAlt';
import CardGiftcardOutlinedIcon from '@mui/icons-material/CardGiftcardOutlined';
import ReactImageMagnify from 'react-image-magnify';
import ReactSlick from "react-slick";
import { useAlert } from "react-alert"
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getProductDetails, postReview } from '../../redux/slices/product';
import { cartActions } from '../../redux/slices/cart';
import getMediaEndPoint from '../../utils/getEndPointForMedia';


const ProductDetails = () => {

    const [tabIndex, setTabIndex] = React.useState(0);
    const [quantity, setQuantity] = useState(0);
    const [details, setDetails] = useState({});
    const [img, setImg] = useState(null);
    const [review, setReview] = useState("");
    const navigate = useNavigate();
    const params = useParams();
    const dispatch = useDispatch();
    const alert = useAlert();
    const userState = useSelector(state => state.user.data)
    const { loading } = useSelector(state => state.product)

    useEffect(() => {
        let promise = dispatch(getProductDetails(params.id));
        promise.unwrap()
            .then(res => {
                if (res.statusCode === 200) {
                    setDetails(res.data);
                    setImg(res.data.images[0]);
                }
            })
        return () => {
            promise?.abort();
        }
    }, [params.id]);

    const handleImageChangeClick = (img) => {
        setImg(img);
    }

    const handleQuantityChange = (type) => {
        if (type === "dec" && quantity !== 0) {
            setQuantity(quantity - 1);
            return;
        }

        if (type === "inc") {

            setQuantity(quantity + 1);
            return;
        }
    }

    const handleTabChange = (event, newValue) => {
        setTabIndex(newValue);
    };

    function a11yProps(index) {
        return {
            id: `simple-tab-${index}`,
            'aria-controls': `simple-tabpanel-${index}`,
        };
    }

    const handleSubmitReview = async () => {
        if (!userState?._id) {
            alert.error("Please login first")
            return;
        }

        if (!review.trim()) {
            alert.error("Please write review first");
        }

        dispatch(postReview({ productId: details._id, user: userState._id, message: review }))
            .then(() => {
                let data = dispatch(getProductDetails(params.id));
                data.unwrap()
                    .then(res => {
                        if (res.statusCode === 200) {
                            setDetails(res.data);
                            setImg(res.data.images[0]);
                        }
                    })
            })
    }

    const handleButNow = () => {
        if (details.availability) {
            dispatch(cartActions.addProduct({ data: details, quantity: 1 }));
            setQuantity(0);
            navigate("/checkout")
            return;
        }

        alert.error("Product is out of stock")
    }

    const handleAddToCart = () => {
        if (!details.availability) {

            alert.error("Product is out of stock")
            return;
        }
        if (quantity > 0) {
            dispatch(cartActions.addProduct({ data: details, quantity }));
            setQuantity(0);
            alert.success("Added to cart")
            return;
        }

        alert.error("Please add some quantity")
    }




    const settings = {
        dots: true,
        arrows: false,
        infinite: false,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay: false,
    }

    return (
        <section style={{ backgroundColor: "white" }}>
            <Container sx={{ py: "50px" }}>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={12} md={12} lg={9} xl={9}>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6} md={6} lg={5} xl={5}>
                                <ReactImageMagnify
                                    className='image-magnifier'
                                    smallImage={{
                                        alt: "Ecommerce product",
                                        isFluidWidth: true,
                                        src: `${getMediaEndPoint()}/images/${img}`,
                                    }}
                                    largeImage={{
                                        src: `${getMediaEndPoint()}/images/${img}`,
                                        width: 1200,
                                        height: 1800,
                                    }}
                                    enlargedImagePosition="over"
                                    isHintEnabled
                                    shouldHideHintAfterFirstActivation={false}
                                />
                                <Box sx={{ pb: "20px" }}>
                                    <ReactSlick {...settings}>
                                        {
                                            details.images?.map((el, i) => (
                                                <img
                                                    key={i}
                                                    src={`${getMediaEndPoint()}/images/${el}`}
                                                    onClick={() => handleImageChangeClick(el)}
                                                    alt="ecommerce product preview"
                                                    className='product-detail-images'
                                                />
                                            ))
                                        }
                                    </ReactSlick>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={6} md={6} lg={7} xl={7}>
                                <Typography variant='h6' fontWeight="bolder">
                                    {details.name}
                                </Typography>
                                <Typography variant='body1' className='productPrice'>
                                    ${details.price} &nbsp;
                                    {/* <del> Rs. 927 </del> &nbsp;
                                    <span> (10% off) </span> */}
                                </Typography>
                                {/* <p className='freeHomeDelivery'>
                                    Free Home Delivery in Pakistan
                                </p> */}
                                <Box display="flex" flexWrap="wrap">
                                    <Typography className='productAvailabilty'>
                                        Availability &nbsp;
                                        <span style={{ color: details.availability ? "" : "red" }}>
                                            {
                                                details.availability ?
                                                    <>In Stock </> :
                                                    <> Out of Stock </>
                                            }
                                        </span>
                                    </Typography>
                                </Box>
                                <div className='QuantityContainer'>
                                    <span> Quantity </span>
                                    <div className='QuantityHandler'>
                                        <button onClick={() => handleQuantityChange("dec")}>
                                            -
                                        </button>
                                        <input type="number" value={quantity} disabled />
                                        <button onClick={() => handleQuantityChange("inc")}>
                                            +
                                        </button>
                                    </div>
                                </div>
                                <Box className='ProductButtonContainer'>
                                    <Button onClick={handleButNow}> Buy Now </Button>
                                    <Button startIcon={<CartIcon />} onClick={handleAddToCart}> Add to Cart </Button>
                                </Box>
                                <Box>
                                    <Typography variant="body1">
                                        Categories
                                    </Typography>
                                    <br />
                                    <Chip label="Category 1" /> &nbsp;
                                    <Chip label="Category 2" /> &nbsp;
                                    <Chip label="Category 3" /> &nbsp;
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                                <Box>
                                    <Tabs onChange={handleTabChange} value={tabIndex}>
                                        <Tab label="Description" {...a11yProps(0)} />
                                        <Tab label="Write a Review" {...a11yProps(1)} />
                                        <Tab label={`Reviews (${details.reviews?.length || 0})`}  {...a11yProps(2)} />
                                    </Tabs>
                                </Box>
                                <TabPanel value={tabIndex} index={0}>
                                    <Typography>
                                        {details.description}
                                    </Typography>
                                </TabPanel>
                                <TabPanel value={tabIndex} index={1}>
                                    <TextField
                                        type="text"
                                        disabled={!!details.userReview}
                                        value={details.userReview?.message || review}
                                        onChange={(e) => setReview(e.target.value)}
                                        multiline
                                        rows={10}
                                        fullWidth
                                    />
                                    <br />
                                    <br />
                                    <Button disabled={!!details.userReview} loading={loading} type="primary" sx={{ mt: 3 }} onClick={handleSubmitReview}>
                                        Submit
                                    </Button>
                                </TabPanel>
                                <TabPanel value={tabIndex} index={2}>
                                    {
                                        details.reviews?.map((el, index) => (
                                            <Typography key={index}>
                                                {el.message}
                                            </Typography>
                                        ))
                                    }

                                    {/* Render Reviews */}
                                </TabPanel>
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={3} xl={3}>
                        <Box bgcolor="#f1f1f1" className='FreeHomeDevliveryAside'>
                            <div className='aside-item'>
                                <div className='aside-item-icon'>
                                    <AirportShuttleIcon />
                                </div>
                                <div>
                                    Free Home Delivery <br />
                                    <label> (Delivered in 3 - 5 days) </label>
                                </div>
                            </div>
                            <div className='aside-item'>
                                <div className='aside-item-icon'>
                                    <CachedIcon />
                                </div>
                                07 Day Return Policy
                            </div>
                            <div className='aside-item'>
                                <div className='aside-item-icon'>
                                    <ThumbUpOffAltIcon />
                                </div>
                                <div>
                                    Friendly Customer Care
                                </div>
                            </div>
                            <div className='aside-item'>
                                <div className='aside-item-icon'>
                                    <CardGiftcardOutlinedIcon />
                                </div>
                                <div>
                                    Pay Cash on Delivery, Bank Transfer, Debit / Credit Cards
                                </div>
                            </div>
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </section>
    )
}

export default ProductDetails;


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};
