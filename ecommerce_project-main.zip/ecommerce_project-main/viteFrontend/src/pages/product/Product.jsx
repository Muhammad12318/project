import React from 'react'
import "./Product.css"
const Product = () => {
  return (
    <section>
      
    </section>
  )
}

export default Product
