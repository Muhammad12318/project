
import { Box } from "@mui/material";
import React, { useRef, useState } from "react";
import MessageContainer from "./components/MessageContainer";
import MessageTypeBar from "./components/MessageInputBar";
import MyStyles from "./Styles";
import SendMessageAPI from "../../services/chat";

const Chat = () => {

  const classes = MyStyles();
  const [loading, setLoading] = useState(false);
  const [allMessages, setAllMessages] = useState([
    {
      sentBy: "bot",
      message: "Hi! What can i do for you!",
      createdAt: new Date(),
    },
  ]);


  const sendMessage = async (message) => {
    if (message.trim()) {
      setAllMessages((pre) => [...pre, { sentBy: "user", message, createdAt: new Date() }])
      setLoading(true);
      let res = await SendMessageAPI(message)
      setLoading(false);
      setAllMessages((pre) => [...pre, { sentBy: "bot", message: res.data, createdAt: new Date() }])

    }
  };


  return (
    <div style={{ overflowY: "hidden" }}>
      <Box className={classes.rootContainer}>
        <MessageContainer loading={loading} allMessages={allMessages} />
        <Box sx={{ position: "relative" }}>
          <MessageTypeBar loading={loading} sendMessage={sendMessage} />
        </Box>
      </Box>
    </div>
  );
};


export default Chat;
