import React, { useEffect, useRef } from "react";
import { Box, Typography } from "@mui/material";
import { Spin } from "antd";
import MyStyles from "../Styles";
import dateFormater from "../../../utils/dateFormaterHandler"

const MessageContainer = ({ allMessages, loading }) => {

  const classes = MyStyles();
  const messageRef = useRef(null);

  useEffect(() => {
    messageRef.current?.scrollIntoView({ behavior: "smooth", });
  }, [allMessages]);


  const RenderMessage = ({ data, index }) => {
    return (
      <div style={{ marginBlock: "10px" }} ref={messageRef}>
        <Typography
          className={
            data.sentBy === "user"
              ? classes.RightMessage
              : classes.LeftMessage
          }
        >
          <p dangerouslySetInnerHTML={{ __html: data.message }} />
          <small
            style={{
              fontSize: "10px",
              display: "block",
              textAlign: "right",
              paddingLeft: "10px",
              marginTop: "15px",
              float: "right",
            }}>
            {dateFormater(data.createdAt, "time")}
          </small>
        </Typography>
        <Box sx={{ clear: "both" }} />
      </div>
    );
  };
  return (
    <Box className={classes.MessagesContainer}>
      {allMessages.map((el, i) => (
        <RenderMessage data={el} key={i} index={i} />
      ))}
      {
        loading &&
        <div style={{ marginBlock: "10px" }} ref={messageRef}>
          <Typography className={classes.LeftMessage}>
            <p style={{width: "150px", fontSize: "10px", fontStyle: "italic"}}>
              Generating Response...
            </p>
            <small
              style={{
                fontSize: "10px",
                display: "block",
                textAlign: "right",
                paddingLeft: "10px",
                marginTop: "15px",
                float: "right",
              }}>
              {dateFormater(new Date(), "time")}
            </small>
          </Typography>
          <Box sx={{ clear: "both" }} />
        </div>
      }
    </Box>
  );
};

export default MessageContainer;
