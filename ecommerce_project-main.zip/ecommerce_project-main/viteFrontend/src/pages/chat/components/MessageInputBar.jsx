import { Box, Input, Button } from "@mui/material"
import MyStyles from "../Styles";
import React, { useState } from "react";
const MessageTypeBar = ({ sendMessage, loading }) => {

  const [message, setMessage] = useState("");
  const classes = MyStyles();


  const handleMessageInput = (e) => {
    setMessage(e.target.value);
  };


  return (
    <Box className={classes.MessageTypeBoxContainer}>
      <Input
        className={classes.MessageInput}
        disableUnderline
        multiline
        maxRows={4}
        placeholder="Type message..."
        onChange={handleMessageInput}
        value={message}
      />
      <Button
        className={classes.SendIcon}
        disabled={loading}
        onClick={() => {
          sendMessage(message);
          setMessage("")
        }}
        variant="contained"
      >
        Send
      </Button>
    </Box>
  );
};

export default MessageTypeBar;
