import { makeStyles } from "@mui/styles";
import { grey } from "@mui/material/colors";

const MyStyles = makeStyles({
  rootContainer: {
    width: "100%",
    overflowY: "hidden",
    height: "60vh",
  },
  MessagesContainer: {
    width: "320px",
    padding: "10px",
    borderLeft: `1px solid ${grey[300]}`,
    overflowY: "auto",
    height: "50vh",
    scrollbarWidth: "thin",
    scrollbarColor: grey[400],
    backgroundColor: grey[200],
    "&::-webkit-scrollbar": {
      width: "5px",
    },
    "&::-webkit-scrollbar-track": {
      color: "transparent",
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: grey[400],
    },
  },
  MessageTypeBoxContainer: {
    position: "absolute",
    botton: 0,
    left: 0,
    right: 0,
    backgroundColor: grey[200],
    padding: "10px",
    width: "100%",
    display: "flex",
  },
  MessageInput: {
    backgroundColor: "white",
    borderRadius: "10px",
    width: "90%",
    minHeight: "50px",
    margin: "0px 10px",
    padding: "10px 5px",
  },
  SendIcon: {
    borderRadius: "5px",
    color: "white",
    height: "50px",
    width: "10%",
  },
  LeftMessage: {
    float: "left",
    borderRadius: "10px",
    borderTopLeftRadius: "0px",
    backgroundColor: "var(--theme-color)",
    padding: "10px",
    maxWidth: "300px",
    color: "white !important",
    textTransform: "unset !important",
  },
  RightMessage: {
    float: "right",
    borderRadius: "10px",
    borderTopRightRadius: "0px",
    backgroundColor: "white",
    padding: "10px",
    maxWidth: "300px",
    textTransform: "unset !important",
  },
});

export default MyStyles;
