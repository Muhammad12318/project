import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Form, Row, Col, Input, Typography, Button, Divider, message } from "antd";
import { Container } from '@mui/material';
import CartItem from './components/CartItem';
import { cartActions } from '../../redux/slices/cart';

const Checkout = () => {

  const dispatch = useDispatch();
  const { products } = useSelector(state => state.cart);

  const [form] = Form.useForm();


  const handleContinueClick = (data) => {
    message.config({top: 100});
    if(products.length){
      message.success("Your order has been placed");
      form.resetFields();
      dispatch(cartActions.clear())
      return;
    }
    message.error("Please add some products to cart first");
  }

  return (
    <Container sx={{ py: 3 }}>
      <br />
      <br />
      <Form layout='vertical' onFinish={handleContinueClick} form={form}>
        <Row gutter={20}>
          <Col xs={24} sm={24} md={12}>
            <Typography.Title level={2}>
              Personal Information
            </Typography.Title>
            <Typography.Text style={{ marginTop: "-20px" }}>
              Use a permanent address where you can receive mail.
            </Typography.Text>
            <Row gutter={10}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="First Name" name="firstName" rules={[{ message: "First Name is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="Last Name" name="lastName" rules={[{ message: "Last Name is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={10}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="City" name="city" rules={[{ message: "City is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="State" name="state" rules={[{ message: "State is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={10}>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="Street Address" name="streetAddres" rules={[{ message: "Street Address is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
              <Col xs={24} sm={24} md={12}>
                <Form.Item label="ZIP / Postal code" name="postalCode" rules={[{ message: "ZIP / Postal code is required!", required: true }]}>
                  <Input />
                </Form.Item>
              </Col>
            </Row>


            <Form.Item label="Email" name="email" rules={[{ message: "Email is required!", required: true }]}>
              <Input type='email' />
            </Form.Item>

            <Button size="large" type='primary' htmlType='submit' disabled={products.length < 1}>
              Checkout
            </Button>
          </Col>
          <Col xs={24} sm={24} md={12}>
            <Typography.Title level={2}>
              Cart
            </Typography.Title>

            <Divider />
            <br />
            {console.log(products)}

            {
              products.map((el, index) => (
                <CartItem data={el.product} quantity={el.quantity} key={index} />
              ))
            }
          </Col>
        </Row>
      </Form>
    </Container>
  )
}

export default Checkout;