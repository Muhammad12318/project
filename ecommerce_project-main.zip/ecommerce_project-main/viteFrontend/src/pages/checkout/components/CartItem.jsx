import React from 'react'
import NotFound from "../../../assets/img/not-found.png";
import getMediaEndPoint from '../../../utils/getEndPointForMedia';
import "./CartItem.scss"
import { Button, Typography } from 'antd';
import { useDispatch } from 'react-redux';
import { cartActions } from '../../../redux/slices/cart';
const CartItem = ({ data = {}, quantity = 0 }) => {

    const dispatch = useDispatch();

    const handleQuantityChange = (action) => {
        dispatch(cartActions.updateProduct({ id: data._id, action }))
    }
    const removeItem = () => {
        dispatch(cartActions.removeProduct({ id: data._id }))
    }
    return (
        <div className='cart-item'>
            <img
                src={`${getMediaEndPoint()}/images/${data.images[0]}`}
                alt=""
                style={{ width: "70px", height: "70px", objectFit: "cover" }}
                onError={(e) => {
                    e.target.src = NotFound;
                }}
            />
            <div className='product-info'>
                <div className='name-div'>
                    <p> {data.name} </p>
                    <div className='QuantityHandler'>
                        <button type='button' onClick={() => handleQuantityChange("dec")}>
                            -
                        </button>
                        <input type="number" value={quantity} disabled />
                        <button type='button' onClick={() => handleQuantityChange("inc")}>
                            +
                        </button>
                    </div>
                </div>
                <div className='price-div'>
                    <Typography.Text style={{ color: "red", fontSize: "20px" }}>
                        ${data.price * quantity}
                    </Typography.Text>
                    <Button className='remove-btn' onClick={removeItem}>
                        Remove
                    </Button>
                </div>
            </div>
        </div>
    )
}

export default CartItem
