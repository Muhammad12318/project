import React, { useState } from 'react';
import { Box, Container, Grid, Typography } from "@mui/material"
import { styled } from "@mui/material/styles";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import HomeSlider from './components/HomeSlider';
import ToyCheckoutImg from "../../assets/img/checkout-toys.webp";
import MobileSellImg from "../../assets/img/mobile-sell.webp";
import CategoriesOfMonth from './components/CategoriesOfMonth';
import CategoryProducts from './components/CategoryProducts';
import CategoryDetails from './components/CategoryDetails/CategoryDetails';
import { Categories_List, SubCategoriesList, SuperSubCategories } from '../../components/header/Data';
import "./home.css";


const Home = () => {

  const [hoveredMenu, setHoveredMenu] = useState("");

  const handleMouseOver = (el) => {
    setHoveredMenu(el);
  }

  const HomeContainer = styled(Box)(({ theme }) => ({
    padding: "20px 30px",
    paddingBottom: "40px",
    backgroundColor: "white",
    boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
    [theme.breakpoints.down("md")]: {
      backgroundColor: "transparent",
      boxShadow: "none",
    },
  }));

  const MenuItem = styled(Box)(({ theme }) => ({
    borderBottom: "1px",
    paddingRight: "5px",
    borderColor: "grey",
    cursor: "pointer",
    transition: "all 0.2s linear",
    "&:hover": {
      backgroundColor: "var(--theme-color)",
      color: "white",
      borderRadius: "5px",
    },
  }));

  const MenuText = styled(Box)(({ theme }) => ({
    margin: "8px 0px",
    padding: "0px 10px",
    fontWeight: "bold",
    flexGrow: 1,
    textOverflow: "ellipsis",
    fontSize: "11px",
  }));



  return (
    <section>
      <Box sx={{ py: "50px", }}>
        <Container sx={{px: {xs: "0px"}}}>
          <HomeContainer>
            <Grid container spacing={2}>
              <Grid item xs={12} md={4} lg={3} sx={{ display: { xs: "none", md: "block" } }}>
                <Typography variant="h6" sx={{ cursor: "pointer", fontWeight: "bold" }} color="var(--theme-color)">
                  My Markets
                </Typography>
                <br />
                <Box id="mega-menu">
                  {
                    [...Categories_List].splice(0, 8).map((el, i) => (
                      <MenuItem key={i} display="flex" justifyContent="space-between" onMouseEnter={() => handleMouseOver(el)}>
                        <MenuText>
                          {el}
                        </MenuText>
                        <div className='big-menu-icon'>
                          <ArrowForwardIosIcon size={10} />
                        </div>
                      </MenuItem>
                    ))
                  }
                  <MenuItem display="flex" justifyContent="space-between" alignItems="center">
                    <MenuText>
                      More Categories
                    </MenuText>
                    <div className='big-menu-icon'>
                      <ArrowForwardIosIcon />
                    </div>
                  </MenuItem>
                  <Box id="mega-menu-list">
                    <Typography variant='h6' fontWeight="bold" color="var(--theme-color)">
                      {hoveredMenu}
                    </Typography>
                    <br />
                    <Grid container>
                      {
                        SubCategoriesList[hoveredMenu]?.map((el, i) => (
                          <Grid key={i} item md={4}>
                            <Typography
                              color="var(--theme-color)"
                              fontSize="13px"
                              sx={{ cursor: "pointer", py: "5px" }}
                            >
                              {el}
                            </Typography>
                            {
                              SuperSubCategories[el]?.map((ele, i) => (
                                <Typography
                                  key={i}
                                  color="#666"
                                  sx={{
                                    cursor: "pointer",
                                    fontSize: "10px",
                                    py: "4px",
                                  }}
                                >
                                  {ele}
                                </Typography>
                              ))
                            }
                          </Grid>
                        ))
                      }
                    </Grid>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} md={8} lg={6}>
                <HomeSlider />
              </Grid>
              <Grid item xs={12} md={3} lg={3} sx={{ display: { xs: "none", lg: "block" } }}>
                <img src={ToyCheckoutImg} alt="Home_Image" width="100%" />
                <img src={MobileSellImg} alt="Home_Image" width="100%" />
              </Grid>
            </Grid>
          </HomeContainer>
        </Container>
      </Box>
      <CategoriesOfMonth />
      {/* <CategoryDetails /> */}
      <CategoryProducts />

    </section>
  )
}

export default Home
