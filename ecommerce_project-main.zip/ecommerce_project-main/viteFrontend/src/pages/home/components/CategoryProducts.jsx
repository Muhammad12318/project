import React, { useEffect, useState } from 'react'
import { Box, Container, Typography } from "@mui/material";
import { Link } from "react-router-dom";
import ReactSlick from "react-slick"
import { useDispatch } from 'react-redux';
import ProductCard from '../../../common/ProductCard/ProductCard';
import { getAllProducts } from '../../../redux/slices/product';
import getMediaEndPoint from '../../../utils/getEndPointForMedia';
const CategoryProducts = () => {

    const dispatch = useDispatch();
    const [allProducts, setAllProducts] = useState([]);
    useEffect(() => {

        let promise = dispatch(getAllProducts());
        promise.unwrap()
            .then(res => {
                if (res.statusCode === 200) {
                    setAllProducts(res.data);
                }
            })

        return () => {
            promise?.abort();
        }
    }, []);

    const settings = {
        dots: true,
        arrows: false,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 4,
        autoplay: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                }
            },
            {
                breakpoint: 700,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                }
            },
            {
                breakpoint: 420,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    centerMode: true,
                }
            }
        ]
    }
    return (
        <section style={{ backgroundColor: "white", padding: "50px 0px" }}>
            <Container>
                <Box>
                    <Box sx={{ borderBottom: "1px solid #e1e1e1" }}>
                        <Typography variant='h5' fontWeight="bolder"> Products </Typography>
                    </Box>
                    <Box s1x={{ pb: "50px" }}>
                        <ReactSlick {...settings}>
                            {
                                allProducts.map((el, i) => (
                                    <Box
                                        key={i}
                                        sx={{ my: "20px", display: "block", textDecoration: "none", color: "black" }}
                                        component={Link}
                                        to={`/products/${el.id}`}
                                    >
                                        <ProductCard
                                            img={`${getMediaEndPoint()}/images/${el.images[0]}`}
                                            {...el}
                                        />
                                    </Box>
                                ))
                            }
                        </ReactSlick>
                    </Box>
                </Box>
            </Container>
        </section>
    )
}

export default CategoryProducts;
