import React from 'react'
import ReactSlick from "react-slick";
import slider1 from "../../../assets/img/home-slider.webp";
import slider2 from "../../../assets/img/home-slider-2.webp";
import slider3 from "../../../assets/img/slider1.jpg";
import slider4 from "../../../assets/img/slider2.png";
import slider5 from "../../../assets/img/slider3.jpg";
import { Box } from '@mui/material';

const HomeSlider = () => {

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
  }

  const NextArrow = (props) => {
    const { className, style, onClick } = props;
    return (

      <div
        className={className}
        style={{ ...style, backgroundColor: "grey", borderRadius: "50%"}}
        onClick={onClick}
      />
    )
  }

  const PrevArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, backgroundColor: "grey", borderRadius: "50%"}}
        onClick={onClick}
      />
    )
  }

  return (
    <section>
      <ReactSlick {...settings} arrows={false} nextArrow={<NextArrow />} prevArrow={<PrevArrow />}>
        <Box>
          <img src={slider3} width="100%" alt="Slider 1" />
        </Box>
        <Box>
          <img src={slider4} width="100%" alt="Slider 2" />
        </Box>
        <Box>
          <img src={slider5} width="100%" alt="Slider 1" />
        </Box>
      </ReactSlick>
    </section>
  )
}

export default HomeSlider;
