import React from "react";
import { Box, Container, Grid, Typography } from "@mui/material";
// import "./categorydetail.css";
import sideImg from "../../../../assets/img/rto_home.jpg";
import { categories_of_month } from "../../Data";

const CategoryDetails = () => {
  return (
    <>
      <Box sx={{ py: "50px", backgroundColor: "white" }}>
        <Container>
          <Grid container sx={{ border: 1 }}>
            <Grid
              item
              xs={4}
              sx={{
                backgroundImage: `url(${sideImg})`,
                backgroundSize: "cover",
                width: "80%",
                height: "70vh",
                color: "#f5f5f5",
              }}
            >
              <Typography
                variant="h5"
                fontWeight="600"
                marginTop="40px"
                marginLeft={"20px"}
              >
                Machinery
              </Typography>
              {/* <img src={ToyCheckoutImg} alt="Home_Image" width="80%" /> */}
            </Grid>
            <Grid item xs={8}></Grid>
          </Grid>
        </Container>
      </Box>
    </>
  );
};

export default CategoryDetails;
