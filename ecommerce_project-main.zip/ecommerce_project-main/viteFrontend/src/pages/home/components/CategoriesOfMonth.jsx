import { Grid, Box, Container, Paper, Typography  } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'
import { categories_of_month } from '../Data'

const CategoriesOfMonth = () => {
  return (
    <section style={{padding: "50px 0px"}}>
        <Container>
            <Typography variant='h6' fontWeight="600" marginBottom="10px">
                Top Categories of the Month
            </Typography>
            <Grid container spacing={.5}>
                {
                    categories_of_month.map((el, i)=>(
                        <Grid item xs={6} sm={4}  md={3} lg={2} xl={2} key={i}>
                            <Paper 
                                elevation={0} 
                                sx={{
                                    "&:hover": {boxShadow: 5}
                                }}
                            >
                                <Box 
                                    style={{
                                        display: "block",
                                        padding: "20px 0px", 
                                        textAlign: "center",
                                        margin: "0px auto",
                                        minWidth: "100px",
                                        textDecoration: "none",
                                    }}
                                    component={Link}
                                    to={el.to ? el.to: "#"}
                                >
                                    <img src={el.img} alt={el.name} width="100px" height="100px" />
                                    <p style={{fontSize: "12px", color: "black", fontWeight: "bold", marginTop: "5px",}}>
                                        {el.name}
                                    </p>
                                </Box>
                            </Paper>
                        </Grid>
                    ))
                }
            </Grid>
        </Container>
    </section>
  )
}

export default CategoriesOfMonth
