import acrylicclock from "../../assets/img/acrylicclock.webp";
import artificialplants from "../../assets/img/artificialplants.webp";
import babytoys from "../../assets/img/baby-toys.webp";
import beautyandcosmetics from "../../assets/img/beauty-and-cosmetics.webp";
import bedcover from "../../assets/img/bedcover.webp";
import books from "../../assets/img/books.webp";
import customizedteacoasters from "../../assets/img/custom-customized-and-unique-tea-coasters.webp";
import customizedproducts from "../../assets/img/customized-products.webp";
import eyeshadowpalettes from "../../assets/img/eyeshadowpalettes.webp";
import jewellery2 from "../../assets/img/jewellery-2.webp";
import lawncollection from "../../assets/img/lawncollection.webp";
import mascara from "../../assets/img/mascara.webp";
import menaccessories from "../../assets/img/men-accessories.webp";
import mensfootwear from "../../assets/img/mens-footwear.webp";
import mensperfumesforbath from "../../assets/img/mens-perfumes-for-bath.webp";
import mobilecoversandprotectors from "../../assets/img/mobile-covers-and-protectors.webp";
import partyweardresses from "../../assets/img/partyweardresses.webp";
import personalcarandgroming from "../../assets/img/personal-care-and-groming.webp";
import polotshirts from "../../assets/img/polot-shirts.webp";
import sofacover from "../../assets/img/sofacover.webp";
import covid19 from "../../assets/img/covid-19.webp";

const categories_of_month = [
    {
        name: "Acrylic Clock",
        img: acrylicclock,
    },
    {
        name: "Artificial Plants",
        img: artificialplants,
    },
    {
        name: "Bed Cover",
        img: bedcover,
    },
    {
        name: "Eyeshadow Palettes",
        img: eyeshadowpalettes,
    },
    {
        name: "Mascara",
        img: mascara,
    },
    {
        name: "Polo T-shirts",
        img: polotshirts,
    },
    {
        name: "Sofa Covers",
        img: sofacover,
    },
    {
        name: "Customized Products",
        img: customizedproducts,
    },
    {
        name: "Lawn Collection",
        img: lawncollection,
    },
    {
        name: "Makeup",
        img: beautyandcosmetics,
    },
    {
        name: "Party Wear Dresses",
        img: partyweardresses,
    },
    {
        name: "Shavers and Trimmers",
        img: mensperfumesforbath,
    },
    {
        name: "Customized Keychains",
        img: customizedteacoasters,
    },
    {
        name: "Mens Footwear",
        img: mensfootwear,
    },
    {
        name: "Mobile Covers and Protectors",
        img: mobilecoversandprotectors,
    },
    {
        name: "Books & Media",
        img: books,
    },
    {
        name: "Toys",
        img: babytoys,
    },
    {
        name: "Personal Care and Grooming",
        img: personalcarandgroming,
    },
    {
        name: "Women Jewellary",
        img: jewellery2,
    },
    {
        name: "Mens Accessories",
        img: menaccessories,
    },
    {
        name: "Covid Care",
        img: covid19,
    },
];

const categorie_products = [
    {
        categoryName: "Fashion Name",
        products: [
            {
                name: "product name with category for his/her",
                productCode: "29998",
                img: bedcover,
                price: "3000",
                discount: "15%",
                discountedPrice: "2500",
            }
        ]
    },
];
export {
    categories_of_month,
    categorie_products,
}