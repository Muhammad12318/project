import React, { useEffect, useState } from 'react'
import { Paper, TextField, Box, Typography } from '@mui/material';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useAlert } from 'react-alert';
import { LoadingButton } from '@mui/lab';
import { register } from "../../redux/slices/user";
import { FaEnvelope, FaLock, FaUser } from 'react-icons/fa';
const Signup = () => {

  var promise = null;
  const dispach = useDispatch();
  const alert = useAlert();
  const loading = useSelector(state => state.user.loading);
  const [details, setDetails] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "user"
  })

  const inputField = {
    margin: "10px 0px",
  }


  const handleInputs = (event) => {
    let name = event.target.name, value = event.target.value;
    setDetails({ ...details, [name]: value });
  }

  const handleSubmit = async () => {
    promise?.abort();
    if (!details.email || !details.password || !details.fullName || !details.confirmPassword) {
      return alert.error("Some fields are empty!")
    }

    if (details.password !== details.confirmPassword) {
      return alert.error("Password and confirm password is mismatch!")
    }
    promise = dispach(register(details));
    promise.unwrap()
    .then((response) => {
      alert.info(response.msg);
    })
  }

  return (
    <section id="login">
      <Paper elevation={3} sx={{ width: { xs: "90%", sm: "400px", md: "600px" }, p: 3 }}>
        <Typography variant='h3' color="var(--theme-color)">
          Sign Up
        </Typography>
        <Typography variant='caption'>
          Join the world best commerce site.
        </Typography>
        <TextField
          type="text"
          variant="outlined"
          label="Full Name"
          fullWidth
          sx={inputField}
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaUser color="var(--theme-color)" style={{marginRight: "5px"}} />
          }}
          name="fullName"
          required
        />
        <TextField
          type="email"
          variant="outlined"
          label="Email"
          fullWidth
          sx={inputField}
          name="email"
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaEnvelope color="var(--theme-color)" style={{marginRight: "5px"}} />
          }}
        />
        <TextField
          type="password"
          variant="outlined"
          label="Password"
          fullWidth
          sx={inputField}
          name="password"
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaLock color="var(--theme-color)" style={{marginRight: "5px"}} />
          }}
          required
        />
        <TextField
          type="password"
          variant="outlined"
          label="Confirm Password"
          fullWidth
          sx={inputField}
          name="confirmPassword"
          onChange={handleInputs}
          InputProps={{
            startAdornment: <FaLock color="var(--theme-color)" style={{marginRight: "5px"}} />
          }}
          required
        />
        <Typography variant='caption' display="flex" justifyContent="flex-end">
          <Link to="/login"> Already have an account! Login </Link>
        </Typography> <br /><br />
        <Box display="flex" justifyContent={"center"} paddingX="20%">
          <LoadingButton loading={loading} variant='contained' fullWidth onClick={handleSubmit} sx={{color: "white"}}>
            Signup
          </LoadingButton>
        </Box>
      </Paper>
    </section>
  )
}

export default Signup
