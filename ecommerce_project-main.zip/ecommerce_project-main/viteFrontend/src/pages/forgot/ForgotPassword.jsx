import React, { useState } from 'react'
import {message} from "antd";
import { Box, Button, Paper, TextField, Typography } from '@mui/material'
import {FaEnvelope} from "react-icons/fa"
import auth from '../../services/auth';

const ForgotPassword = () => {

  const [email, setEmail] = useState("");
  const inputField = {
    margin: "10px 0px",
  }

  const sendForgotToken = async ()=>{

    let res = await auth.sendForgotPasswordToken(email, `${window.location.origin}/new-password`);
    if(res.statusCode === 200){
        message.config({top: 110});
        message.info("Check your email")
        return;
      }
      message.error("Unable to send email")
  }
  return (
    <section id="login">
      <Paper elevation={3} sx={{ width: { xs: "90%", sm: "400px", md: "600px" }, p: 3 }}>
        <Typography variant='h4' color="var(--theme-color)">
          Forogot Password
        </Typography>
        <Typography variant='caption'>
          Enter your email to recover your password!
        </Typography>
        <TextField
          type="email"
          variant="outlined"
          label="Email"
          fullWidth
          sx={inputField}
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
          InputProps={{
            startAdornment: <FaEnvelope color="var(--theme-color)" style={{marginRight: "5px"}} />
          }}
          required
        />
        <Box sx={{paddingX: "20%"}}>
          <Button variant='contained' onClick={sendForgotToken} fullWidth sx={{color: "white"}}> Send Email </Button>
        </Box>
      </Paper>
    </section>
  )
}

export default ForgotPassword
