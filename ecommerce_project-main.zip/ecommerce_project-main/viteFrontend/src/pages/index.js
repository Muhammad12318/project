import ForgotPassword from "./forgot/ForgotPassword"
import Home from "./home/Home"
import Login from "./login/Login"
import ProductDetails from "./product/ProductDetails"
import Product from "./product/Product"
import Signup from "./signup/Signup"
import Chat from "./chat/Chat"
import Sell from "./sell"
import SearchProducts from "./searchProducts/SearchProducts"
import Checkout from "./checkout/Checkout"
import NewPassword from "./new-password/NewPassword"
const Pages = {
    NewPassword,
    Sell,
    ProductDetails,
    Product,
    ForgotPassword,
    Home,
    Signup,
    Login,
    Chat,
    SearchProducts,
    Checkout

}

export default Pages;