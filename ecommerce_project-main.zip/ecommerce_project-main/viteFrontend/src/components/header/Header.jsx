import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import Badge from "@mui/material/Badge";
import UserIcon from "@mui/icons-material/Person";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import SearchIcon from '@mui/icons-material/Search';
import { logout } from "../../redux/slices/user";
import localStorageManager from "../../utils/localStorageManage";
import SiteVars from "../../constants/SiteVars"
import Categories from "./components/Categories"
const settings = [ "Sell", "Logout"];


function Header() {

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [anchorElUser, setAnchorElUser] = useState(null);
  const { products } = useSelector(state => state.cart);
  const userState = useSelector((state) => state.user.data);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = (setting) => {
    setAnchorElUser(null);
    if (setting === "Logout") {
      navigate("/");
      localStorageManager.clearStorage();
      dispatch(logout({}));
      return;
    }
    if (setting) {
      navigate("/" + setting);
    }
  };


  return (
    <>
      <AppBar position="sticky">
        <Container>
          <Toolbar disableGutters>
            <Box
              sx={{ display: { xs: "none", lg: "flex" }, mr: 1, pt: "10px" }}
              component={Link}
              to="/"
            >
              <img
                src={SiteVars.Logo}
                width={90}
                alt={`${SiteVars.NAME} logo`}
              />
            </Box>
            <Box
              sx={{
                flexGrow: 1,
                display: { xs: "flex", lg: "none" },
                mr: 1,
                pt: "10px",
              }}
              justifyContent="center"
              component={Link}
              to="/"
            >
              <img
                src={SiteVars.Logo}
                width={100}
                alt={`${SiteVars.NAME} logo`}
              />
            </Box>
            <Box sx={{ flexGrow: 1, display: "flex", justifyContent: "flex-end", alignItems: "center", marginInline: 2 }}>
              <Tooltip title="Search Products">
                <IconButton>
                  <Link to="/products/search" className="login-icon">
                    <SearchIcon />
                  </Link>
                </IconButton>
              </Tooltip>
              <Tooltip title="Search Products">
                <Badge badgeContent={products.length} color="info" overlap="circular">
                  <IconButton>
                    <Link to="/checkout" className="login-icon">
                      <ShoppingCartIcon />
                    </Link>
                  </IconButton>
                </Badge>
              </Tooltip>
            </Box>

            <Box sx={{ flexGrow: 0 }}>
              <Tooltip title={userState?.role ? `Open settings` : "Login"}>
                <IconButton
                  onClick={userState?.role ? handleOpenUserMenu : null}
                  sx={{ p: 0 }}
                  color="inherit"
                >
                  {userState?.role ? (
                    <Avatar
                      alt="Remy Sharp"
                      src="/static/images/avatar/2.jpg"
                    />
                  ) : (
                    <Link to="/login" className="login-icon">
                      <UserIcon fontSize="16px" />
                    </Link>
                  )}
                </IconButton>
              </Tooltip>
              <Menu
                id="menu-appbar"
                anchorEl={anchorElUser}
                keepMounted
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                    mt: 1.5,
                    '& .MuiAvatar-root': {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    '&:before': {
                      content: '""',
                      display: 'block',
                      position: 'absolute',
                      top: 0,
                      right: 14,
                      width: 10,
                      height: 10,
                      bgcolor: 'background.paper',
                      transform: 'translateY(-50%) rotate(45deg)',
                      zIndex: 0,
                    },
                  },
                }}
                open={Boolean(anchorElUser)}
                onClose={() => handleCloseUserMenu()}
              >
                {settings.map((setting, index) => {
                  if (setting.toLocaleLowerCase() === "sell" && userState?.role !== "admin") {
                    return null
                  }
                  return (
                    <MenuItem
                      key={index}
                      onClick={() => handleCloseUserMenu(setting)}
                      sx={{ width: "150px" }}
                    >
                      <Typography textAlign="center">{setting}</Typography>
                    </MenuItem>
                  )

                })}
              </Menu>
            </Box>
          </Toolbar>
        </Container>
        <Box sx={{ display: { sm: "block", md: "none", lg: "none" } }}>
          <Categories />
        </Box>
      </AppBar>
    </>
  );
}
export default Header;
