import React from "react";
import { Drawer, IconButton, Toolbar, Typography } from "@mui/material";
import List from '@mui/material/List';
import Box from '@mui/material/Box';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import CloseIcon from '@mui/icons-material/CloseOutlined';
import MenuIcon from '@mui/icons-material/Menu';
import { useNavigate } from "react-router-dom";
import {pages} from "../Data";

const MobileList = (anchor) => {

    const [openDrawer, setOpenDrawer] = React.useState(false);
    const navigate = useNavigate();

    const toggleDrawer = (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }

        setOpenDrawer(!openDrawer);
    };

    const onQuickLinkClick = (path)=>{
        toggleDrawer({type: "close"});
        navigate(path);
    }

    const list = () => (
        <Box
            sx={{ width: 250 }}
            role="presentation"
            // onClick={toggleDrawer()}
            // onKeyDown={toggleDrawer()}
        >
            <List sx={{pt: 0}}>
                <Toolbar sx={{backgroundColor: "#dd2400"}}>
                    <Typography variant="h5" color="white" fontWeight="900" sx={{flexGrow: 1}}>
                        Quick Links
                    </Typography>
                    <IconButton color="inherit" onClick={toggleDrawer}>
                        <CloseIcon sx={{color: "white"}} />
                    </IconButton>
                </Toolbar>
                <ListItem disablePadding>
                        <ListItemButton onClick={()=>onQuickLinkClick("/")}>
                            <ListItemText primary="Home" />
                        </ListItemButton>
                </ListItem>
                {pages.map((el, index) => (
                    <ListItem key={index} disablePadding>
                        <ListItemButton onClick={()=>onQuickLinkClick(el.path)}>
                            {/* <ListItemIcon>
                            </ListItemIcon> */}
                            <ListItemText primary={el.name} />
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
        </Box>
    )

    return (
        <>
            <IconButton 
                color="inherit"
                aria-label="menu" 
                onClick={toggleDrawer}
            >
                <MenuIcon />
            </IconButton>
            <Drawer
                anchor={"left"}
                open={openDrawer}
                onClose={toggleDrawer}
            >
                {list(anchor)}
            </Drawer>
        </>
    )
};

export default MobileList;