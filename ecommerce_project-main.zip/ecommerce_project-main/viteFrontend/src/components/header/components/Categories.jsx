import { Button, Container, Typography, Grid, Box, Menu } from "@mui/material";
import ReactSlick from "react-slick";
import React, { useState } from 'react';
import { SubCategoriesList, SuperSubCategories, Categories_List } from "../Data";
import "../header.css";

const Categories = () => {

    const [hoveredMenu, setHoveredMenu] = useState("");
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleOpen = (event, txt) => {
        setHoveredMenu(txt);
        setAnchorEl(event.currentTarget);
    };

    const handleClose = (e) => {
        setAnchorEl(null);
    };

    const settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 4,
        autoplay: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                }
            },
            {
                breakpoint: 420,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    centerMode: true,
                }
            }
        ]
    }
    return (
        <>
            <div className="CategoriesBar">
                <Container>
                    <ReactSlick {...settings}>
                        {
                            Categories_List.map((el, i) => (
                                <Typography
                                    className="CategoryBtn"
                                    key={i}
                                    sx={{
                                        mx: 2,
                                        color: 'white',
                                        whiteSpace: "nowrap",
                                        flexShrink: 0,
                                        textTransform: "capitalize",
                                        textOverflow: "ellipsis",
                                        width: "100px",
                                        fontSize: "13px",
                                        textAlign: "center",
                                    }}
                                    onClick={(e) => handleOpen(e, el)}
                                    aria-owns={open ? 'categories-menu' : undefined}
                                    aria-haspopup="true"
                                >
                                    {el}
                                </Typography>
                            ))
                        }
                    </ReactSlick>
                    <Menu
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleClose}
                        id="categories-menu"
                        marginThreshold={0}
                        anchorOrigin={{ vertical: 'bottom', horizontal: "center" }}
                        transformOrigin={{ vertical: 'top', horizontal: "center" }}
                        MenuListProps={{
                        }}
                        PaperProps={{
                            style: {
                                width: "100%",
                                maxWidth: "100%",
                                left: 0,
                                right: 0,
                                zIndex: 1300,
                            }
                        }}
                    >
                        <Box
                            id="categories-submenu"
                            sx={{
                                height: "300px",
                                boxSizing: "border-box",
                                overflowY: "auto",
                                backgroundColor: "white",
                                "&::-webkit-scrollbar, & *::-webkit-scrollbar": {
                                    backgroundColor: "transparent",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                    borderRadius: 8,
                                    backgroundColor: "#6b6b6b",
                                    minHeight: 24,
                                    border: `6px solid white`,
                                },
                            }}
                        >
                            <Grid container spacing={2} sx={{ px: 2, pt: 2 }}>
                                {
                                    SubCategoriesList[hoveredMenu]?.map((el, i) => (
                                        <Grid key={i} item md={3}>
                                            <Typography
                                                color="var(--theme-color)"
                                                sx={{ cursor: "pointer", fontSize: "13px", py: "5px" }}
                                            >
                                                {el}
                                            </Typography>
                                            {
                                                SuperSubCategories[el]?.map((ele, i) => (
                                                    <Typography
                                                        key={i}
                                                        color="#666"
                                                        fontWeight="bold"
                                                        sx={{
                                                            cursor: "pointer",
                                                            fontSize: "10px",
                                                            py: "4px",
                                                        }}
                                                    >
                                                        {ele}
                                                    </Typography>
                                                ))
                                            }
                                        </Grid>
                                    ))
                                }
                            </Grid>
                        </Box>
                    </Menu>
                </Container>
            </div>
        </>
    )
}

export default Categories
