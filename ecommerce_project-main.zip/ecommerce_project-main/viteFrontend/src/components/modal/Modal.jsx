import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import CloseOutlined from '@mui/icons-material/CloseOutlined';
import { IconButton } from '@mui/material';

export default function Modal({
    open = false,
    onClose = () => { },
    children,
    maxWidth = "sm",
    fullScreen = false,
    title = "Title",
    actions = <></>,
}) {

    return (
        <React.Fragment>
            <Dialog
                fullWidth
                fullScreen={fullScreen}
                maxWidth={maxWidth}
                open={open}
                onClose={onClose}
            >
                <DialogTitle {...(fullScreen ? {bgcolor: "var(--dark-blue)", color: "white"}: {color: "var(--dark-blue)"})} variant='h5' fontWeight="bold" sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    {title}
                    <IconButton onClick={onClose} color="inherit">
                        <CloseOutlined {...(fullScreen ? {color: "inherit"}: {})} />
                    </IconButton>
                </DialogTitle>
                <DialogContent>
                    <br />
                    {children}
                </DialogContent>
                <DialogActions>
                    {actions}
                </DialogActions>
            </Dialog>
        </React.Fragment>
    );
}