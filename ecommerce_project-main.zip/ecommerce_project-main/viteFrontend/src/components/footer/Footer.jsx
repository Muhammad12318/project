import { Grid } from '@mui/material';
import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <>
      <Grid container className="footer-background">
        <Grid item xs={12} md={4} lg={4} xl={4}>
          ssssss
        </Grid>
        <Grid item xs={12} md={4} lg={4} xl={4}>
          ssssss
        </Grid>
        <Grid item xs={12} md={4} lg={4} xl={4}>
          ssssss
        </Grid>
      </Grid>
    </>
  );
}

export default Footer
