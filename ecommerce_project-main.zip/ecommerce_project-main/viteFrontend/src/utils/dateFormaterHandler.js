import dateFormate from "dateformat";
const dateFormaterHandler = (date = new Date(), formatter, shortTimeWithYT = true)=>{

    if(formatter === "time"){
        return dateFormate(date, "shortTime");
    }

    const dt = dateFormate(date, "DDDD");
    if(dt === "Today"){
        return dateFormate(date, "shortTime")
    }
    else if(dt === "Yesterday"){
        return dt + ( shortTimeWithYT ? " " + dateFormate(date, "shortTime"): "");
    } else {
        return dateFormate(date, "shortDate") + (shortTimeWithYT ? " " + dateFormate(date, "shortTime") : "");
    }
    
}

export default dateFormaterHandler;