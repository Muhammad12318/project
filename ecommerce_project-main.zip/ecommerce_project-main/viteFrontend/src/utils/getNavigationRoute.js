const getNavigationRoute = (role)=>{
    if(role === "admin"){
        return "/admin/dashboard";
      }
    if(role === "user"){
    return "/";
    }

    return "/login"
}

export default getNavigationRoute;