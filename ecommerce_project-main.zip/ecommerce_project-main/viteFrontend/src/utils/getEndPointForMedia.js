const getMediaEndPoint = ()=>{

    return process.env.NODE_ENV === "production" ? "/public" : "http://localhost:4000/public";
}

export default getMediaEndPoint;