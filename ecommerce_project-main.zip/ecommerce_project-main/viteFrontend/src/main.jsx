import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from "react-router-dom";
import { Provider } from 'react-redux';
import {store} from './redux/store';
import { ThemeProvider } from '@mui/material/styles';
import App from './App';
import THEME from './theme/Theme';
import { ConfigProvider } from 'antd';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Provider store={store}>
        <ThemeProvider theme={THEME}>
          <ConfigProvider theme={{token: {colorPrimary: "#4a044e"}}}>
            <App />
          </ConfigProvider>
        </ThemeProvider>
      </Provider>
    </BrowserRouter>
  </React.StrictMode>
);