import axios from "axios";
import getServerEndpoint from "../utils/getServerEndpoint";

const getUserById = async (id)=>{
    if(id){
        return await axios.get(`${getServerEndpoint()}users/user/${id}`)
        .then(res=>res?.data)
        .catch(err=>err?.response?.data)
    }
    return null;
}



const user = {
    getUserById,
}

export default user;