import axios from "axios"
import getServerEndpoint from "../utils/getServerEndpoint";

const SendMessageAPI = async (message) => {
  return await axios.post(`${getServerEndpoint()}bot`, { message })
    .then(res => res.data)
    .catch(err => {
      return { data: "Error Occured" }
    })
};



export default SendMessageAPI;
