import axios from "axios";
import getServerEndpoint from "../utils/getServerEndpoint";
import localStorageManager from "../utils/localStorageManage";
const login = async (body) => {
    return await axios.post(`${getServerEndpoint()}auth/login`, body)
        .then(res => res?.data)
        .catch(err => err?.response?.data);
}

const register = async (body) => {
    return await axios.post(`${getServerEndpoint()}auth/signup`, body)
        .then(res => res?.data)
        .catch(err => err?.response?.data);
}

const verify = async () => {
    let token = localStorageManager.getToken();
    if (token) {
        return await axios.post(`${getServerEndpoint()}auth/verify`, { token })
            .then(res => res?.data)
            .catch(err => err?.response?.data);
    }
    return null;
}

const sendEmailVerificationCode = async (email) => {
    if (email) {
        return await axios.post(`${getServerEndpoint()}auth/send-email-code`, { email })
            .then(res => res?.data)
            .catch(err => err?.response?.data)
    }
    return null;
}

const sendForgotPasswordToken = async (email, url) => {
    if (email) {
        return await axios.post(`${getServerEndpoint()}auth/send-forgot-password-code`, { email, url })
            .then(res => res?.data)
            .catch(err => err?.response?.data)
    }
    return null;
}

const verifyEmailVerificationCode = async (email, code) => {
    if (email) {
        return await axios.post(`${getServerEndpoint()}auth/verify-email-code`, { email, code })
            .then(res => res?.data)
            .catch(err => err?.response?.data)
    }
    return null;
}

const changePassword = async (data) => {

    return await axios.post(`${getServerEndpoint()}auth/change-password`, data)
        .then(res => res?.data)
        .catch(err => err?.response?.data)
}
const auth = {
    login,
    register,
    verify,
    sendEmailVerificationCode,
    verifyEmailVerificationCode,
    sendForgotPasswordToken,
    changePassword,
}
export default auth;