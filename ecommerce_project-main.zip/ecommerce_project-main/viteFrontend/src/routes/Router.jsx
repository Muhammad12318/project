import React, { useEffect } from 'react';
import { Route, Routes } from "react-router-dom";
import Pages from '../pages';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
const Router = () => {

  const location = useLocation();
  const userState = useSelector((state) => state.user.data);

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [location.pathname])
  return (
    <>
      <Routes>
        <Route index element={<Pages.Home />} />
        {
          userState?.role === "admin" &&
          <Route path='/sell' element={<Pages.Sell />} />
        }

        {
          userState?.role &&
          <Route path='/chat' element={<Pages.Chat />} />
        }
        <Route path='/products' element={<Pages.Product />} />
        <Route path='/products/:id' element={<Pages.ProductDetails />} />
        <Route path='/products/search/' element={<Pages.SearchProducts />} />
        <Route path='/checkout' element={<Pages.Checkout />} />
        {
          !userState?.role &&
          <>
            <Route path='/login' element={<Pages.Login />} />
            <Route path='/forgot-password' element={<Pages.ForgotPassword />} />
            <Route path='/new-password' element={<Pages.NewPassword />} />
            <Route path='/signup' element={<Pages.Signup />} />
          </>
        }
      </Routes>
    </>
  )
}

export default Router
