import React from 'react';
import {Route, Routes} from "react-router-dom";
import Pages from '../pages';
const AdminRoutes = () => {
  return (
    <>
      <Routes>
        <Route index children={()=><p> Admin Routes </p>} />
      </Routes>
    </>
  )
}

export default AdminRoutes
