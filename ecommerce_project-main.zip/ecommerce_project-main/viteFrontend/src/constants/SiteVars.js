import logo from '../assets/img/logo.png'
const SiteVars = {
    NAME: "E-Commerce",
    Logo: logo,
    PhoneNumber: "+92300-0000000",
    WhatsApp: "+92300-00000000"
}

export default SiteVars;