import { configureStore } from '@reduxjs/toolkit';
import user from "./slices/user";
import product from "./slices/product";
import cart from "./slices/cart";
export const store = configureStore({
  reducer: {
    cart: cart,
    user: user,
    product: product,
  },
})