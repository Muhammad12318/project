import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import getServerEndpoint from "../../utils/getServerEndpoint";
import localStorageManager from "../../utils/localStorageManage";

const initialState = {
  loading: false,
  data: null,
};

const logout = createAsyncThunk(
  'logout',
  async (data) => {
    return initialState;
  }
)
const login = createAsyncThunk(
  'login',
  async (data, { signal }) => {
    return await axios.post(`${getServerEndpoint()}auth/login`,
      data,
      { signal }
    )
      .then(res => res?.data)
      .catch(err => err?.response?.data);
  }
)

const register = createAsyncThunk(
  'signup',
  async (data, { signal }) => {
    return await axios.post(`${getServerEndpoint()}auth/signup`,
      data,
      { signal }
    )
      .then(res => res?.data)
      .catch(err => err?.response?.data);
  }
)

const verify = createAsyncThunk(
  'verify',
  async (data, { signal }) => {
    let token = localStorageManager.getToken();
    if (token) {
      return await axios.post(`${getServerEndpoint()}auth/verify`,
        { token },
        { signal }
      )
        .then(res => res?.data)
        .catch(err => err?.response?.data);
    }
    return {
      msg: "No token found"
    };
  }
)

const sendEmailVerificationCode = createAsyncThunk(
  'send-email-code',
  async (email, { signal }) => {
    if (email) {
      return await axios.post(`${getServerEndpoint()}auth/send-email-code`,
        { email },
        { signal }
      )
        .then(res => res?.data)
        .catch(err => err?.response?.data)
    }
    return null;
  }
)

const verifyEmailVerificationCode = createAsyncThunk(
  'verify-email-code',
  async ({ email, code }, { signal }) => {
    if (email && code) {
      return await axios.post(`${getServerEndpoint()}auth/verify-email-code`,
        { email, code },
        { signal })
        .then(res => res?.data)
        .catch(err => err?.response?.data)
    }
    return null;
  }
)

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(logout.fulfilled, (state, action) => {
      state.data = {};
      state.loading = false;
    })
    builder.addCase(login.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        localStorageManager.setUser(action.payload.data);
        localStorageManager.setToken(action.payload.data?.token);
        action.payload.msg = "Login success";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
    })
    builder.addCase(login.pending, (state, action) => {
      // action penidng
      state.loading = true;
      state.data = {};
    })
    builder.addCase(login.rejected, (state, action) => {
      // request rejected
    })
    builder.addCase(register.fulfilled, (state, action) => {
      // action fullfilled
      // do what ever you want
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      state.data = action.payload;
      state.loading = false;
    })
    builder.addCase(register.pending, (state, action) => {
      // action pending
      state.loading = true;
      state.data = {};
    })
    builder.addCase(register.rejected, (state, action) => {
      // request rejected
    })
    builder.addCase(verify.fulfilled, (state, action) => {
      // action fullfilled
      // do what ever you want
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        localStorageManager.setUser(action.payload.data);
        localStorageManager.setToken(action.payload.data?.token);
        action.payload.msg = "Verify success";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
      state.data.msg = action.payload.msg
      state.loading = false;
    })
    builder.addCase(verify.pending, (state, action) => {
      // actin pending
      state.loading = true;
      state.data = {};
    })
    builder.addCase(verify.rejected, (state, action) => {
      // Request Rejected
    })
    builder.addCase(sendEmailVerificationCode.fulfilled, (state, action) => {
      // action fullfilled
      // do what ever you want
      state.data.msg = action.payload.msg
      state.loading = false;
    })
    builder.addCase(sendEmailVerificationCode.pending, (state, action) => {
      // action pending
      state.loading = true;
      state.data = {};
    })
    builder.addCase(sendEmailVerificationCode.rejected, (state, action) => {
      // request rejected
    })
    builder.addCase(verifyEmailVerificationCode.fulfilled, (state, action) => {
      // action fullfilled
      // do what ever you want
      state.data.msg = action.payload.msg
      state.loading = false;
    })
    builder.addCase(verifyEmailVerificationCode.pending, (state, action) => {
      // action pending
      state.loading = true;
      state.data = {};
    })
    builder.addCase(verifyEmailVerificationCode.rejected, (state, action) => {
      // request rejected
    })
  }
})

export { login, verify, sendEmailVerificationCode, verifyEmailVerificationCode, register, logout };

export default userSlice.reducer