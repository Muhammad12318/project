import { createSlice } from "@reduxjs/toolkit";
const getLocalProducts = () => {
    try {
        return JSON.parse(localStorage.getItem("user-products")) || []
    } catch (err) {

    }
}
const setLocalProducts = (products) => {
    try {
        localStorage.setItem("user-products", JSON.stringify(products))
    } catch (err) {

    }
}

const sortProducts = (products) => {
    return products.sort((a, b) => {
        if (a.product.name < b.product.name) {
            return -1;
        }
        if (a.product.name > b.product.name) {
            return 1;
        }
        return 0;
    });
}
const cartSlice = createSlice({
    name: "cart",
    initialState: { products: getLocalProducts() },
    reducers: {
        addProduct: (state, action) => {
            const { data: product, quantity } = action.payload;

            const isAlreadyAdded = state.products.find(el => el?.product?._id === product?._id);
            if (isAlreadyAdded) {
                const remainingProducts = state.products.filter(el => el?.product?._id !== product?._id);
                const newProducts = [...remainingProducts, { product, quantity: quantity + isAlreadyAdded.quantity }];
                state.products = sortProducts(newProducts);
                setLocalProducts(newProducts);
                return;
            }

            state.products = sortProducts([...state.products, { product, quantity }]);
            setLocalProducts([{ product, quantity }]);
        },
        removeProduct: (state, action) => {
            const { id } = action.payload;
            const newProducts = state.products.filter(el => el?.product?._id !== id)
            state.products = sortProducts(newProducts);
            setLocalProducts(newProducts);
        },
        updateProduct: (state, action) => {
            const { id, action: operator } = action.payload
            const product__ = state.products.find(el => el?.product?._id === id);
            const remainingProducts = state.products.filter(el => el?.product?._id !== id);
            const quantity = operator === "inc" ?
                product__.quantity + 1 :
                product__.quantity - 1

            const updatedProducs = quantity ? [
                ...remainingProducts,
                {
                    ...product__,
                    quantity,
                }
            ] : remainingProducts;

            state.products = sortProducts(updatedProducs);
            setLocalProducts(updatedProducs);

        },

        clear: (state, action)=>{
            state.products = [];
        }
    }

})

export const cartActions = cartSlice.actions;
export default cartSlice.reducer;