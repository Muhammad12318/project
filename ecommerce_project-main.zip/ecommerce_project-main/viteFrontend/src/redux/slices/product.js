import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import axios from 'axios';
import getServerEndpoint from '../../utils/getServerEndpoint';

const initialState = {
  loading: false,
  data: null,
  reviewRes: {},
  searchRes: {},
  searchResults: [],
};

export const postProduct = createAsyncThunk(
  'post-product',
  async (data, { signal }) => {
    return await axios.post(`${getServerEndpoint()}products/`, data, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)

export const postReview = createAsyncThunk(
  'post-reviews',
  async (data, { signal }) => {
    return await axios.post(`${getServerEndpoint()}products/${data.productId}/reviews`, data, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)



export const getUserProducts = createAsyncThunk(
  'get-user-product',
  async (data, { signal }) => {
    return await axios.get(`${getServerEndpoint()}products/user-products`, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)

export const getProductDetails = createAsyncThunk(
  'get-product-details',
  async (id, { signal }) => {
    return await axios.get(`${getServerEndpoint()}products/${id}`, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)

export const getAllProducts = createAsyncThunk(
  'get-product',
  async (data, { signal }) => {
    return await axios.get(`${getServerEndpoint()}products/`, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)

export const getSearchProducts = createAsyncThunk(
  'search-product',
  async (parameters, { signal }) => {

    return await axios.get(`${getServerEndpoint()}products/search?search=${parameters.search}&price=${parameters.price || ""}&sort=${JSON.stringify(parameters.sort) || ""}`, { signal })
      .then(res => res?.data)
      .catch(err => err?.response?.data)
  }
)

export const chatSlice = createSlice({
  name: 'product',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(postProduct.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(postProduct.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        action.payload.msg = "Product Posted Successfully";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
    })
    builder.addCase(getAllProducts.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(getAllProducts.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        action.payload.msg = "Product Fetched Successfully";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
    })
    builder.addCase(getUserProducts.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(getUserProducts.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        action.payload.msg = "Product Fetched Successfully";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
    })
    builder.addCase(getProductDetails.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(getProductDetails.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        action.payload.msg = "Product Fetched Successfully";
        state.data = action.payload.data;
      } else {
        state.data = action.payload
      }
      state.loading = false;
    })
    builder.addCase(postReview.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(postReview.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
      if (action.payload.statusCode === 200) {
        action.payload.msg = "Product Review Posted Successfully";
        state.data = action.payload.data;
      } else {
        state.reviewRes = action.payload
      }
      state.loading = false;
    })
    builder.addCase(getSearchProducts.pending, (state, action) => {
      state.loading = true;
    })
    builder.addCase(getSearchProducts.fulfilled, (state, action) => {
      if (!action.payload) {
        action.payload = {
          msg: "Unknown error occured"
        }
      }
        console.log("=============")

      if (action.payload.statusCode === 200) {
        action.payload.msg = "Search Product Fetched Successfully";
        state.searchResults = action.payload.data;
      } else {
        state.searchRes = action.payload
      }
      state.loading = false;
    })
  }
})


export default chatSlice.reducer