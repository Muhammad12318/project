import React, {useLayoutEffect, useEffect, useState} from "react";
import axios from "axios";
import {Avatar, Popover, Tooltip} from "antd"
import AlertTemplate from "react-alert-template-basic";
import { positions, Provider } from "react-alert";
import { useLocation } from "react-router";
import { verify } from "./redux/slices/user";
import Header from './components/header/Header';
import Router from './routes/Router';
import localStorageManager from "./utils/localStorageManage";
import { useDispatch, useSelector } from "react-redux";
import chatSupportImg from "./assets/img/chat_support.png"
import Chat from "./pages/chat/Chat";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './App.css';

const options = {
  timeout: 2500,
  position: positions.BOTTOM_CENTER,
  containerStyle: {
    zIndex: 1000000,
  },
};

function App() {

  const location = useLocation();
  const dispatch = useDispatch();
  const [showChat, setShowChat] = useState(false);
  const user = useSelector(state=>state.user.data)


  useLayoutEffect(() => {
    axios.interceptors.request.use(
      config => {
        const token = localStorageManager.getToken();
        if (token) {
          config.headers['Authorization'] = 'Bearer ' + token;
        }
        return config;
      },
      error => {
        Promise.reject(error)
      });
  }, [])

  useEffect(() => {
    let promise = dispatch(verify());
    return ()=>{
      promise?.abort();
    }
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);


  return (
    <>
      <Provider template={AlertTemplate} {...options}>
        <Header />
        <main>
          <Router />
          {
          user?.role &&
          <Popover trigger={["click"]} content={<Chat />} placement="topRight" onOpenChange={setShowChat}>
            <Tooltip title="Need any help?" defaultOpen showArrow open={!showChat}>
              <Avatar src={chatSupportImg} size={60} className="chat-support-icon" />
            </Tooltip>
          </Popover>
          }
        </main>
      </Provider>
    </>
  );
}

export default App;
