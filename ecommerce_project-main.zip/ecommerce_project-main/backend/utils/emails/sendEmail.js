const nodemailer = require('nodemailer');
const VerifyEmailTemplate = require("./templates/VerifyEmail");
const ForgotPasswordTemplate = require("./templates/ForgotPassword");
require('dotenv').config();


const SendEmail = async (email, code, url) => {
    mailTransporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL,
            pass: process.env.PASS,
        }
    });

    mailDetails = {
        from: 'mailhere.com',
        to: email,
        subject: url? "Forgot Your Password":'Verifying Your Email',
        html: url ? ForgotPasswordTemplate(code, url) : VerifyEmailTemplate(code)
    };

    await mailTransporter.sendMail(mailDetails)

}

module.exports = SendEmail;