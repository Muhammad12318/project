const express = require("express");
const routes = require("../constants/routes");
const controllers = require("../controller");
const router = express();

router.use(routes.AUTH, controllers.auth);
router.use(routes.ADMIN, controllers.admin);
router.use(routes.USER, controllers.user);
router.use(routes.CHATS, controllers.chat);
router.use(routes.PRODUCTS, controllers.product);
router.use(routes.BOT, controllers.bot);
module.exports = router;