const mongoose = require("mongoose");

const productReviewsSchema = mongoose.Schema({
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        required: [true, "Product Id is required"],
        ref: "product",
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: [true, "Product Id is required"],
        ref: "user",
    },
    message: {
        type: String,
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
})

const productReviewModal = mongoose.model("productReviews", productReviewsSchema);

module.exports = productReviewModal;