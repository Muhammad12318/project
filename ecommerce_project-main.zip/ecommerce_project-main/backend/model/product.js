const mongoose = require("mongoose");
const ProductSchema = mongoose.Schema({
    postedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: [true, "Poster id is required"],
        ref: "user",
    },
    name: {
        type: String,
        required: [true, "Name is required"]
    },
    condition: {
        type: String,
        require: [true, "Condition is required."],
        enum: {
            values: [
                "used",
                "new",
            ],
            message:
                "Condtion must be new or used",
        },
    },
    price: {
        type: Number,
        required: [true, "Minimum price is required"],
    },
    minimumOrderQuantity: {
        type: Number,
        required: [true, "Minimum Order Quantity is required."]
    },
    keywords: {
        type: Array,
        required: [true, "Keywords are required"],
    },
    location: {
        type: String,
        required: [true, "Location is required"],
    },
    availability: {
        type: Boolean,
        required: [true, "Availability is required"],
    },
    description: {
        type: String,
        required: [true, "Description is required"]
    },
    images: {
        type: Array,
        minlength: [3, "At least three Images are required"],
        required: [true, "Images is required"]
    },
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
})

ProductSchema.virtual("reviews", {
    ref: "productReviews",
    localField: "_id",
    foreignField: "productId",
})


const ProductModel = mongoose.model("product", ProductSchema);
module.exports = ProductModel;