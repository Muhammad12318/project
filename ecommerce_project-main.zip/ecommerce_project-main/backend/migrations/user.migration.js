const userModel = require("../model/user");
const createUsers = async () => {

    await userModel.updateOne({ _id: "63fadacf7977af7703187b95" }, {
        $set: {
            "fullName": "Admin",
            "email": "admin@ecommerce.com",
            // password is 12345678
            "password": "$2a$08$5bd6hCt7XEvA/mkNQqvMZueRmBbyTiOZHF6zB7RLz7lX4elq7CNbC",
            "banned": false,
            "isEmailVerified": true,
            "isPhoneVerified": true,
            "role": "admin",
            "createdAt": "2023-02-25T09:23:45.492Z",
            "updatedAt": "2023-07-14T20:11:44.414Z",
            "__v": 0,
        }
    })
}

module.exports = createUsers;