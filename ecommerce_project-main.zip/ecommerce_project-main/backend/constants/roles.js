module.exports = {
    STUDENT: "student",
    ADMINSTAFF: "adminStaff",
    ADMIN: "admin",
    TUTOR: "tutor",
}