const version = "v1";
module.exports = {
  PRODUCTS: `/${version}/products`,
  CHATS: `/${version}/chats`,
  AUTH: `/${version}/auth`,
  USER: `/${version}/users`,
  ADMIN: `/${version}/admin`,
  BOT: `/${version}/bot`,
};
