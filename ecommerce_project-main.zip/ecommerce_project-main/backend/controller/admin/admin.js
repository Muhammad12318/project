const STATUS_CODE = require("../../constants/statusCode");
const userModel = require("../../model/user");
