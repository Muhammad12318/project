const auth = require("./auth/index");
const admin = require("./admin/index");
const user = require("./user/index");
const chat = require("./chat/index");
const product = require("./product/index");
const bot = require("./openai/index");
const controllers = {
    auth,
    admin,
    user,
    chat,
    product,
    bot,
}

module.exports = controllers;