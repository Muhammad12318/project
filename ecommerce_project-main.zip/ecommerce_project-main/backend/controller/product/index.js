const express = require("express");
const router = express();
const product = require("./product");
const auth = require("../../middlewares/auth/auth");
const catchAsync = require("../../utils/CatchAsync");
const uploadMulter = require("../../utils/multer");


router.get("/", catchAsync(product.getAll));
router.get("/search", catchAsync(product.search));
router.get("/user-products", auth.authenticate, catchAsync(product.getUserProducts));
router.get("/:id", catchAsync(product.getById));
router.post("/", auth.authenticate, uploadMulter.fields([{ name: "images", maxCount: 5 }]), catchAsync(product.post));
router.post("/:id/reviews", auth.authenticate, catchAsync(product.postReview));

module.exports = router;