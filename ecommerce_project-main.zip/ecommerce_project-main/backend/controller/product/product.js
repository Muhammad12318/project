const { promisify } = require("util");
const roles = require("../../constants/roles");
const STATUS_CODE = require("../../constants/statusCode");
const productModel = require("../../model/product");
const SaveToPublic = require("../../utils/saveFileToPublic");
const productReviewModal = require("../../model/productReviews");
const { authenticate, getUserFromToken } = require("../../middlewares/auth/auth");
exports.post = async (req, res) => {

    let images = [];
    if (req.files?.images) {
        for (let image of req.files.images) {
            images.push(SaveToPublic(image, "image"));
        }
    }

    if (!req.body.name) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Product name is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }
    if (!req.body.description) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Product description is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }
    if (!req.body.availability && req.body.availability !== false) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Product availability is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }

    let data = new productModel({
        ...req.body,
        images: images,
        postedBy: req.user.id,
    });
    await data.save();
    res.status(STATUS_CODE.OK).json({ msg: "Product Created Successfully", statusCode: STATUS_CODE.OK });
}
exports.getById = async (req, res) => {
    let _id = req.params.id;
    if (!_id) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Id is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }

    const doc = await productModel.findOne({ _id })
        .populate({
            path: "reviews",
            populate: {
                path: "user"
            }
        })

    let user = await getUserFromToken(req.headers)
    if (user) {
        let userReview = await productReviewModal.findOne({ user: user._id, productId: _id })
        res.status(STATUS_CODE.OK).json({ data: { ...doc.toObject(), userReview }, statusCode: STATUS_CODE.OK });
        return;
    }
    if (doc) {
        res.status(STATUS_CODE.OK).json({ data: doc, statusCode: STATUS_CODE.OK });
        return;
    }
    res.status(STATUS_CODE.NOT_FOUND).json({ msg: "Not found", statusCode: STATUS_CODE.NOT_FOUND });
}


exports.getUserProducts = async (req, res) => {
    await productModel.find({ postedBy: req.user.id })
        .then(doc => {
            if (doc) {
                res.status(STATUS_CODE.OK).json({ data: doc, statusCode: STATUS_CODE.OK });
                return;
            }
            res.status(STATUS_CODE.NOT_FOUND).json({ msg: "Not found", statusCode: STATUS_CODE.NOT_FOUND });
        })
}
exports.getAll = async (req, res) => {
    // await productModel.find().limit(30)
    await productModel.find()
        .then(doc => {
            if (doc) {
                res.status(STATUS_CODE.OK).json({ data: doc, statusCode: STATUS_CODE.OK });
                return;
            }
            res.status(STATUS_CODE.NOT_FOUND).json({ msg: "Not found", statusCode: STATUS_CODE.NOT_FOUND });
        })
}

exports.search = async (req, res) => {

    let search = req.query.search,
        sortParam = req.query.sort,
        price = req.query.price;
    let sort = {
        id: -1,
    }

    let condition = {
    };
    if (search) {
        condition.$and = [
            ...(condition.$and || []),
            {
                $or: [
                    { "name": { "$regex": search, "$options": "i" } },
                    { "description": { "$regex": search, "$options": "i" } },
                ]
            }
        ]
    }
    if (price) {
        condition.$and = [
            ...(condition.$and || []),
            { price: { $lt: price } }
        ]
    }
    if (sortParam) {
        try {
            sort = JSON.parse(sortParam);
        } catch (err) { }
    }

    console.log(JSON.stringify(condition, null, 4))
    await productModel.find(condition).sort(sort)
        .then(doc => {
            if (doc) {
                res.status(STATUS_CODE.OK).json({ data: doc, statusCode: STATUS_CODE.OK });
                return;
            }
            res.status(STATUS_CODE.NOT_FOUND).json({ msg: "Not found", statusCode: STATUS_CODE.NOT_FOUND });
        })
}
exports.postReview = async (req, res) => {
    if (!req.params.id) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Product id is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }
    if (!req.body.user) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "User id is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }
    if (!req.body.message) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ msg: "Message id is required.", statusCode: STATUS_CODE.BAD_REQUEST });
        return;
    }

    let data = new productReviewModal({
        ...req.body,
        productId: req.params.id,
    })

    await data.save();

    res.status(STATUS_CODE.OK).json({ msg: "Review Posted Successfully", statusCode: STATUS_CODE.OK });
    return;
}