const express = require("express");
const router = express();
const openai = require("./openai");
const catchAsync = require("../../utils/CatchAsync")
router.post("/", catchAsync(openai.generateResponse));

module.exports = router;