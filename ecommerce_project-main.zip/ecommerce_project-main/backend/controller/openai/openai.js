const { Configuration, OpenAIApi } = require("openai");
const STATUS_CODE = require("../../constants/statusCode");

const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
    organization: "org-mf9bq0WHfFLtwgR5nLTrN12C",
})

const openai = new OpenAIApi(configuration);

exports.generateResponse = async (req, res) => {

    if (!req.body.message) {
        res.status(STATUS_CODE.BAD_REQUEST).json({ statusCode: STATUS_CODE.BAD_REQUEST, msg: "body is required" })
        return;
    }
    const chatCompletion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [{role: "user", content: req.body.message}],
        temperature: 1,
        max_tokens: 100,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
    });

    res.status(STATUS_CODE.OK).json({ statusCode: STATUS_CODE.OK, data: chatCompletion.data.choices[0].message.content })
    return;
}