<?php
require 'includes/init.php';


if(isset($_SESSION['user_id']) && isset($_SESSION['email'])){
  $user_data = $client_object->find_user_by_id($_SESSION['user_id']);
  if($user_data ===  false){
      header('Location: logout.php');
      exit;
  }
  // FETCH ALL USERS WHERE ID IS NOT EQUAL TO MY ID
  $all_users = $client_object->all_users($_SESSION['user_id']);
}
else{
  header('Location: logout.php');
  exit;
}
// REQUEST NOTIFICATION NUMBER
$get_req_num = $frnd_obj->request_notification($_SESSION['user_id'], false);
// TOTAL FRIENDS
$get_frnd_num = $frnd_obj->get_all_friends($_SESSION['user_id'], false);


// IF USER MAKING SIGNUP REQUEST
if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])) {


  $result = $client_object->updateUser($_POST['username'], $_POST['email'], $_POST['password'], $_FILES['image']['name']);
}
// IF USER ALREADY LOGGED IN
// if (isset($_SESSION['email'])) {
//   header('Location: my-profile.php');
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Update profilen</title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="./assets/css/font-awesome.css" />
  <link rel="stylesheet" href="./assets/css/bootstrap.css">
  <link rel="stylesheet" href="./assets/css/cstm.css">
  <link rel="stylesheet" href="./style.css">
  <!-- js files -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
</head>

<body style="background: rgb(107, 107, 107) !important;">
  <?php include("./navigation.php") ?>
  <!-- Page content -->
<div class="content">
  <div class="text-center">
    <img src="profile_images/<?php echo $user_data->user_image; ?>" class="card-img-top" alt="Profile image">
  </div>    
    <h5 class="card-user_name text-center"><?php echo  $user_data->username;?></h5>
    <p class="card-user text-center">Update profile</p>
  <div class="card component-card_3 col-12 col-sm-12 col-lg-6 col-md-12 col-xl-6">
            <div class="card-body">    
                
                <div class="card">
                    <div class="card-body">
                    
                    <form action="" method="POST" novalidate enctype="multipart/form-data">
                    <div class="form-group">
                      <label for="username" class="lable-style">Full Name</label>
                      <input type="text" id="username"  class="form-control" name="username" spellcheck="false" placeholder="Enter your full name"    value="<?php echo  $user_data->username; ?>"  required>
                    </div>
                    <div class="form-group">
                      <label for="email" class="lable-style">Email</label>
                      <input type="email" id="email" class="form-control" name="email" spellcheck="false" placeholder="Enter your email address"  value="<?php echo  $user_data->user_email; ?>" required>
                    </div>
                    <div class="form-group">
                      <label for="password" class="lable-style">Password</label>
                      <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password"  required>
                    </div>
                    <div class="form-group">
                      <label for="image" class="lable-style">Image</label>
                      <input type="file" class="form-control" id="image" name="image" required>
                    </div>
                      <img src="profile_images/<?php echo $user_data->user_image; ?>" width="150px" height="auto" alt="">
                      <br>
                      <br>
                      <input type="submit" name="upload"  class="btn btn-outline-primary" style="border-radius: 2.3rem;" value="Update Profile">

                      </form>
                      <div>
                      <?php
                      if (isset($result['errorMessage'])) {
                        echo '<div class="alert alert-primary" role="alert">
                              ' . $result['errorMessage'] . '
                            </div>';
                      }
                      if (isset($result['successMessage'])) {
                        echo '<div class="alert alert-primary" role="alert">
                        ' . $result['successMessage'] . '
                      </div>';
                      }
                      ?>
                      </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php
        if (isset($result['errorMessage'])) {
          echo '<p class="errorMsg">' . $result['errorMessage'] . '</p>';
        }
        if (isset($result['successMessage'])) {
          echo '<p class="successMsg">' . $result['successMessage'] . '</p>';
        }
        ?>
      </div>

    </div>
  </div>

</body>

</html>