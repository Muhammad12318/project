<?php
require 'includes/init.php';
 
// Check Signup Request
if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])){
 
 
  $Res = $client_object->singUpUser($_POST['username'],$_POST['email'],$_POST['password'],$_FILES['image']['name']);
}
// If Session is set
if(isset($_SESSION['email'])){
  header('Location: my-profile.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create new account</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body style="background: rgb(107, 107, 107) !important;">
  <div class="wrap_area login_container_area">
    <h1>Create new account</h1>
    <form action="" method="POST" novalidate  enctype="multipart/form-data">
      <!-- Full Name -->
      <label for="username">Full Name</label>
      <input type="text" id="username" name="username" placeholder="Enter your full name" required/>
      <!-- Email -->
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email address" required />
      <!-- Password -->
      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required />
      <!-- Image -->
      <label for="image">image</label>
      <input type="file" id="image" name="image" required />
      <br>
      <br>
      <!-- Submit Button -->
      <input type="submit"  name="upload" value="Sign Up">
      <a href="login.php" class="form_link">Already have an account?</a>
    </form>
    <div>  
      <?php
        if(isset($Res['errorMessage'])){
          echo '<p class="errorMsg">'.$Res['errorMessage'].'</p>';
        }
        if(isset($Res['successMessage'])){
          echo '<p class="successMsg">'.$Res['successMessage'].'</p>';
        }
      ?>    
    </div>
 
  </div>
</body>
</html>

