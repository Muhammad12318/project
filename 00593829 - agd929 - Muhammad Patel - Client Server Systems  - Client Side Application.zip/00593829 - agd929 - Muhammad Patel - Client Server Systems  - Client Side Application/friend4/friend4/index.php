<?php
require 'includes/init.php';
 
$search = isset($_POST['search'])? $_POST['search']:'';
//  $all_users = $client_object->all_user($search);
 
//$data = range(1, 150); // data array to be paginated
 
if($search != ''){

    $q =("SELECT * FROM `users` WHERE `username` LIKE '$search'");
    // print_r($get_users);
    // die();  
}  else{
    $q = "SELECT * FROM users ORDER BY id DESC  LIMIT 8";
}
$query = $db_connection->prepare($q);
$query->execute();

if($query->rowCount() > 0){
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
}
   
    
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo  $user_data->username;?></title>
    <link rel="stylesheet" href="./style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/css/mdb.min.css">
    <link rel="stylesheet" href="./style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,600;1,200;1,300&display=swap" rel="stylesheet">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <a href="./login.php">Login</a>
  <form class="form-inline" action="index.php" method="POST">
            <input class="form-control mr-sm-2 p-2" type="text" name="search" id="search" placeholder="Search" aria-label="Search">
  </form>
</div>

<!-- Page content -->
<div class="content">
        <h1>User's List</h1>
        <ul class="list-group" id = "post-data">
            <?php
            if (isset($result)) {
                foreach ($result as $row) {
                    echo '
                                <li class="list-group-item d-flex justify-content-between align-items-center postid"  id="'.$row['id'].'">
                                <div class="image-parent d-flex   align-items-center">
                                      <img src="profile_images/' . $row['user_image'] . '" class="img-thumbnail" alt="quixote">
                                      <h5 class="pl-4">' . $row['username'] . '</h5>
                                    </div> 
                                             
                                        <a href="user-profile.php?id=' . $row['id'] . '" class="btn btn-outline-primary" style="border-radius: 2.3rem;">See profile</a>
                                    
                                </li>
                                ';
                }
            } else {
                echo '<h4 class="text-center">There is no user!</h4>';
            }
            ?>
        </ul>
    </div>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
                $(window).scroll(function() {
                    if ($(window).scrollTop() >= $(document).height() - $(window).height() - 10) {
                        var last_id = $(".postid:last").attr("id");
                        
                        loadMore(last_id);
                    }
                });

                function loadMore(last_id){
                  
                $.ajax({
                    url: 'load-more.php?last_id=' + last_id,
                    type: "get",
                    beforeSend: function(){
                        $('.ajax-load').show();
                    }
                }).done(function(data){
                 // console.log(data);
                  $('.ajax-load').hide();
                        $('.list-group').append(data);
                    // $('.ajax-load').hide();
                    // $("#post-data").append(data);
                }).fail(function(jqXHR, ajaxOptions, thrownError){
                    alert('server not responding...');
                });
                }
</script> 
</body>
</html>