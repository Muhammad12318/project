<?php
require 'includes/init.php';

if (isset($_SESSION['user_id']) && isset($_SESSION['email'])) {

    $user_data = $client_object->find_user_by_id($_SESSION['user_id']);
    if ($user_data ===  false) {
        header('Location: logout.php');
        exit;
    }
    // FETCH ALL USERS WHERE ID IS NOT EQUAL TO MY ID

    // $all_users = $client_object->all_users($_SESSION['user_id']);
} else {
  
    header('Location: logout.php');
    exit;
}
// REQUEST NOTIFICATION NUMBER
$get_req_num = $frnd_obj->request_notification($_SESSION['user_id'], false);
// TOTAL FRIENDS
$get_frnd_num = $frnd_obj->get_all_friends($_SESSION['user_id'], false);


$search = isset($_POST['search']) ? $_POST['search'] : '';
//  $all_users = $client_object->all_user($search);

if ($search != '') {

    $q = ("SELECT * FROM `users` WHERE `username` LIKE '$search'");
    // print_r($get_users);
    // die();  
} else {
    $q = "SELECT * FROM users ORDER BY id DESC  LIMIT 8";
}
$query = $db_connection->prepare($q);
$query->execute();

if ($query->rowCount() > 0) {
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
}
$uid = $_SESSION['user_id'];

//SELECT u.*, f.user_one , f.user_two from users as u , friends as f where (u.id = f.user_one || u.id = f.user_two) && u.id='430';
$map = ("SELECT u.*, f.user_one , f.user_two from users as u , my_friends as f where (u.id = f.user_one || u.id = f.user_two) && (f.user_one='430' || f.user_two || $uid )");

$query_map = $db_connection->prepare($map);
$query_map->execute();
// print_r($query_map);
if ($query_map->rowCount() > 0) {
    $result_map = $query_map->fetchAll(PDO::FETCH_ASSOC);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo  $user_data->username; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/css/mdb.min.css">
    <link rel="stylesheet" href="./style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,600;1,200;1,300&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif !important;
        }
    </style>
</head>

<body>

    <!--Navbar blue-->
    <?php include 'navigation.php'; ?>
    <!-- Page content -->
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyArhvduxZjES-tJ4dg89omMnH0OQ_yb4Bc" type="text/javascript"></script>
    <div id="wrapper">
        <div class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel_s">
                        <div class="panel-body">

                            <div id="map" style="width: 100%; height: 800px;"></div>

                            <script type="text/javascript">
                                var locations = [

                                    <?php foreach ($result_map as $t) {
                                        if ($t['id'] == $uid) {
                                            continue;
                                        }


                                        if ($t['longitude']   != '' && $t['latitude'] != '') {

                                    ?>['<?php echo $t['username'] ?>',
                                                <?php echo $t['longitude'] ?>, <?php echo $t['latitude'] ?>, "profile_images/<?php echo $t['user_image_map']; ?>"],

                                    <?php }
                                    } ?>

                                    // else{
                                    //     ['Coogee Beach', 28.5562, 77.1000, 5],
                                    // ['Cronulla Beach', 28.6824, 77.1080, 3],
                                    // ['Manly Beach', 28.6724, 77.2800, 2],
                                    // ['Maroubra Beach', 28.4724, 77.1450, 1]
                                    // }

                                ];


                                var map = new google.maps.Map(document.getElementById('map'), {
                                    zoom: 10,
                                    center: new google.maps.LatLng(-33.8688, 151.2093),
                                    mapTypeId: google.maps.MapTypeId.ROADMAP
                                });

                                var infowindow = new google.maps.InfoWindow();

                                var marker, i;
                                var image = 'profile_images/1.jpg';
                                for (i = 0; i < locations.length; i++) {
                                    marker = new google.maps.Marker({
                                        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                                        map: map,
                                        icon: locations[i][3]
                                    });

                                    google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                        return function() {
                                            infowindow.setContent(locations[i][0]);
                                            infowindow.open(map, marker);
                                        }
                                    })(marker, i));
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        taskid = '<?php echo $taskid; ?>';
        $(function() {
            tasks_kanban();
        });
    </script>
    <div class="content">
        <div style="text-align: center;">
            <img src="profile_images/<?php echo $user_data->user_image; ?>" class="card-img-top" alt="Profile image">
        </div>
        <h5 style="text-align: center;" class="card-user_name"><?php echo  $user_data->username; ?></h5>
        <p style="text-align: center;" class="card-user">All Users</p>
        <ul class="list-group" id = "post-data">
                <?php
                if (isset($result)) {
                    foreach ($result as $row) {
                        echo '
                                    <li class="list-group-item d-flex justify-content-between align-items-center postid"  id="'.$row['id'].'">
                                    <div class="image-parent d-flex   align-items-center">
                                        <img src="profile_images/' . $row['user_image'] . '" class="img-thumbnail" alt="quixote">
                                        <h5 class="pl-4">' . $row['username'] . '</h5>
                                        </div> 
                                                
                                            <a href="user-profile.php?id=' . $row['id'] . '" class="btn btn-outline-primary" style="border-radius: 2.3rem;">See profile</a>
                                        
                                    </li>
                                    ';
                    }
                } else {
                    echo '<h4 class="text-center">There is no user!</h4>';
                }
                ?>
            </ul>
        
    </div>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>
        $(window).scroll(function() {
            if ($(window).scrollTop() >= $(document).height() - $(window).height() - 10) {
                var last_id = $(".postid:last").attr("id");

                loadMore(last_id);
            }
        });

        function loadMore(last_id) {

            $.ajax({
                url: 'load-more.php?last_id=' + last_id,
                type: "get",
                beforeSend: function() {
                    $('.ajax-load').show();
                }
            }).done(function(data) {
                // console.log(data);
                $('.ajax-load').hide();
                $('.list-group').append(data);
                // $('.ajax-load').hide();
                // $("#post-data").append(data);
            }).fail(function(jqXHR, ajaxOptions, thrownError) {
                alert('server not responding...');
            });
        }
    </script>
</body>

</html>