<div class="sidebar">
  <a href="my-profile.php">Home</a>
  <a href="notify.php">Requests
  <span class="badge <?php
            if($get_req_num > 0){
                echo 'redBadge';
            }
            ?>"><?php echo $get_req_num;?>
    </span>
  </a>
  <a href="my-friends.php">
      Friends
    <span class="badge"><?php echo $get_frnd_num;?></span>
  </a>
  <a href="edit-profile.php" >Edit</a>
  <a href="logout.php" >Logout</a>
  <form class="form-inline" action="my-profile.php" method="POST">
            <input class="form-control mr-sm-2 p-2" type="text" name="search" id="search" placeholder="Search" aria-label="Search">
  </form>
</div>






