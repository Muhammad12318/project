<?php
require 'includes/init.php';
// IF USER MAKING LOGIN REQUEST
if(isset($_POST['email']) && isset($_POST['password'])){
  $result = $client_object->loginUser($_POST['email'],$_POST['password']);
}
// if(!isset($_SESSION['email'])){
//   header('Location: home.php');
//   exit;
// }

// IF USER ALREADY LOGGED IN
if(isset($_SESSION['email'])){
  header('Location: my-profile.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body style="  background: rgb(107, 107, 107) !important;">
  <div class="wrap_area login_container_area">
    
    <form action="" method="POST">
    <h1>Welcome back!</h1>
      <label for="email">Email  <span style="color:red"> *</span> </label>
      <input type="email" id="email" name="email" spellcheck="false" placeholder="Enter your email address" required>
      <label for="password">Password  <span style="color:red"> *</span></label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required>
      <div class="d-flex align-item-center">
        <input type="submit" value="Login">
        <a href="create-acc.php" class="form_link">Create new account</a>
      </div>
      <div>  
      <?php
        if(isset($result['errorMessage'])){
          echo '<p class="errorMsg">'.$result['errorMessage'].'</p>';
        }
        if(isset($result['successMessage'])){
          echo '<p class="successMsg">'.$result['successMessage'].'</p>';
        }
      ?>    
    </div>
    </form>
 
  </div>
</body>
</html>