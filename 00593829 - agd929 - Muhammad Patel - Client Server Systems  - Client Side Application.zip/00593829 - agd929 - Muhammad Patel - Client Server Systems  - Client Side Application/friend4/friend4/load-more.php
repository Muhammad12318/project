<?php
require 'includes/init.php';
$q = ("SELECT * FROM `users` WHERE id < '".$_GET['last_id']."' ORDER BY id DESC   LIMIT 8");
// print_r($get_users);
// die();  
// }
$query = $db_connection->prepare($q);
$query->execute();

if ($query->rowCount() > 0) {
$result = $query->fetchAll(PDO::FETCH_ASSOC);
}
 
$html = '';
if (isset($result)) {
foreach ($result as $row) {
   
        $html .= '<li class="list-group-item d-flex justify-content-between align-items-center postid"  id="'.$row['id'].'">

                                <div class="image-parent d-flex justify-content-center  align-items-center">
                                      <img src="profile_images/' . $row['user_image'] . '" class="img-fluid" alt="quixote">
                                      <h5 class="pl-4">' . $row['username'] . '</h5>
                                    </div> 
                                             
                                        <a href="user-profile.php?id=' . $row['id'] . '" class="btn btn-primary">See profile</a>
                                    
                                </li>';
    }
    echo  $html;
}





  ?> 