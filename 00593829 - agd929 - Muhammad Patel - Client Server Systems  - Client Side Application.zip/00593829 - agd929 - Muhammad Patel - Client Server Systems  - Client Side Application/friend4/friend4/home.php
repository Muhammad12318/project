<?php
require 'includes/init.php';
 
  $search = isset($_POST['search'])? $_POST['search']:'';
//     $all_users = $client_object->all_user($search);
$start = 0;  $per_page = 4;
$page_counter = 0;
$next = $page_counter + 1;
$previous = $page_counter - 1;

if(isset($_GET['start'])){
  $start = $_GET['start'];
  $page_counter =  $_GET['start'];
  $start = $start *  $per_page;
  $next = $page_counter + 1;
  $previous = $page_counter - 1;
 }
  //include configuration file
  if($search != ''){

      $q =("SELECT * FROM `users` WHERE `username` LIKE '$search'");
      // print_r($get_users);
      // die();  
  }
  else{
     
      $q = "SELECT * FROM users LIMIT $start, $per_page";
  }

  
  if(isset($_GET['start'])){
   $start = $_GET['start'];
   $page_counter =  $_GET['start'];
   $start = $start *  $per_page;
   $next = $page_counter + 1;
   $previous = $page_counter - 1;
  }
  // query to get messages from messages table
 
  $query = $db_connection->prepare($q);
  $query->execute();

  if($query->rowCount() > 0){
      $result = $query->fetchAll(PDO::FETCH_ASSOC);
  }
 
  // count total number of rows in students table
  $count_query = "SELECT * FROM users";
  $query = $db_connection->prepare($count_query);
  $query->execute();
  $count = $query->rowCount();
  // calculate the pagination number by dividing total number of rows with per page.
  $paginations = ceil($count / $per_page);



 
   
    
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo  $user_data->username;?></title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="./assets/css/font-awesome.css" />
  <link rel="stylesheet" href="./assets/css/bootstrap.css">
  <link rel="stylesheet" href="./assets/css/cstm.css">
  <link rel="stylesheet" href="./style.css">
  <!-- js files -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark teal mb-4">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item"><a  class="nav-link active" href="index.php" >Login</a></li>
        </ul>
        <form class="form-inline" action="home.php" method="POST">
            <input class="form-control mr-sm-2" type="text" name="search" id="search" placeholder="Search" aria-label="Search">
        </form>
    </div>
</nav>
<!-- Page content -->
<div class="content">
<div class="card component-card_3 col-12 col-sm-12 col-lg-6 col-md-12 col-xl-6">
            <div class="card-body">
                <p class="card-user">All Users</p>
                
                <div class="card">
                    <div class="card-body">
                    <ul class="list-group">
                        <?php
                        if(isset($result)){
                            foreach($result as $row){
                                echo '
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="image-parent d-flex justify-content-center  align-items-center">
                                      <img src="profile_images/'.$row['user_image'].'" class="img-fluid" alt="quixote">
                                      <h5 class="pl-4">'.$row['username'].'</h5>
                                    </div> 
                                             
                                        <a href="edit-profile.php?id='.$row['id'].'" class="btn btn-outline-primary" style="border-radius: 2.3rem;">See profile</a>
                                    
                                </li>
                                ';
                            }
                        }
                        else{
                            echo '<h4>There is no user!</h4>';
                        }
                        ?>
                        </ul>
                        <div class="paginating-container mt-3 pagination-default">
                        <ul class="pagination">
                        <?php
                            if($page_counter == 0){
                                echo "<li><a href=?start='0' class='active'>0</a></li>";
                                for($j=1; $j < $paginations; $j++) { 
                                echo "<li><a href=?start=$j>".$j."</a></li>";
                            }
                            }else{
                                echo "<li><a href=?start=$previous>Previous</a></li>"; 
                                for($j=0; $j < $paginations; $j++) {
                                if($j == $page_counter) {
                                    echo "<li><a href=?start=$j class='active'>".$j."</a></li>";
                                }else{
                                    echo "<li><a href=?start=$j>".$j."</a></li>";
                                } 
                            }if($j != $page_counter+1)
                                echo "<li><a href=?start=$next>Next</a></li>"; 
                            } 
                        ?>
                        </ul>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    <div class="profile_container">
            <?php
            if(isset($result)){
                foreach($result as $row){
                    echo '<div class="my_user_box">
                            <div class="my_user_img"><img src="profile_images/'.$row['user_image'].'" alt="Profile image"></div>
                            <div class="my_user_info"><span>'.$row['username'].'</span>
                            <span><a href="edit-profile.php?id='.$row['id'].'" class="see_profile_button">See profile</a></div>
                        </div>';
                }
            }
            else{
                echo '<h4>There is no user!</h4>';
            }
            ?>
        </div>
 
            <ul class="pagination">
            <?php
                if($page_counter == 0){
                    echo "<li><a href=?start='0' class='active'>0</a></li>";
                    for($j=1; $j < $paginations; $j++) { 
                      echo "<li><a href=?start=$j>".$j."</a></li>";
                   }
                }else{
                    echo "<li><a href=?start=$previous>Previous</a></li>"; 
                    for($j=0; $j < $paginations; $j++) {
                     if($j == $page_counter) {
                        echo "<li><a href=?start=$j class='active'>".$j."</a></li>";
                     }else{
                        echo "<li><a href=?start=$j>".$j."</a></li>";
                     } 
                  }if($j != $page_counter+1)
                    echo "<li><a href=?start=$next>Next</a></li>"; 
                } 
            ?>
            </ul>
         
        </div>
      -->
    </div>
</div>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
</body>
</html>