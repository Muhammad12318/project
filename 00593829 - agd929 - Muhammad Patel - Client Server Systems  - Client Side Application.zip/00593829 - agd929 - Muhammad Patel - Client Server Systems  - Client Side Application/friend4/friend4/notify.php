<?php
require 'includes/init.php';

if(isset($_SESSION['user_id']) && isset($_SESSION['email'])){
    $user_data = $client_object->find_user_by_id($_SESSION['user_id']);
    if($user_data ===  false){
        header('Location: logout.php');
        exit;
    }
}
else{
    header('Location: logout.php');
    exit;
}
// TOTAL REQUESTS
$get_req_num = $frnd_obj->request_notification($_SESSION['user_id'], false);
// TOTAL FRIENDS
$get_frnd_num = $frnd_obj->get_all_friends($_SESSION['user_id'], false);
$get_all_req_sender = $frnd_obj->request_notification($_SESSION['user_id'], true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo  $user_data->username;?></title>
    <link rel="stylesheet" href="./style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/css/mdb.min.css">
    <link rel="stylesheet" href="./style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,600;1,200;1,300&display=swap" rel="stylesheet">
</head>
<body>
<?php include 'navigation.php';?>
<!-- Page content -->
<div class="content">
    <div class="card component-card_3 col-12 col-sm-12 col-lg-6 col-md-12 col-xl-6">
            <div class="card-body">
                
                
                <div class="card">
                    <div class="card-body">
                    <ul class="list-group">
                        <?php
                         if($get_req_num > 0){
                            foreach($get_all_req_sender as $row){
                                echo '
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="image-parent d-flex justify-content-center  align-items-center">
                                      <img src="profile_images/'.$row->user_image.'" class="img-fluid" alt="quixote">
                                      <h5 class="pl-4">'.$row->username.'</h5>
                                    </div> 
                                             
                                        <a href="user-profile.php?id='.$row->sender.'" class="btn btn-outline-primary" style="border-radius: 2.3rem;">See profile</a>
                                    
                                </li>
                                ';
                            }
                        }
                        else{
                            echo '<h4>You have no friend requests!</h4>';
                        }
                        ?>
                        </ul>
                        <div class="paginating-container mt-3 pagination-default">
                        <!-- <ul class="pagination"> -->
                        <?php
                            // if($page_counter == 0){
                            //     echo "<li><a href=?start='0' class='active'>0</a></li>";
                            //     for($j=1; $j < $paginations; $j++) { 
                            //     echo "<li><a href=?start=$j>".$j."</a></li>";
                            // }
                            // }else{
                            //     echo "<li><a href=?start=$previous>Previous</a></li>"; 
                            //     for($j=0; $j < $paginations; $j++) {
                            //     if($j == $page_counter) {
                            //         echo "<li><a href=?start=$j class='active'>".$j."</a></li>";
                            //     }else{
                            //         echo "<li><a href=?start=$j>".$j."</a></li>";
                            //     } 
                            // }if($j != $page_counter+1)
                            //     echo "<li><a href=?start=$next>Next</a></li>"; 
                            // } 
                        ?>
                            <!-- <li class="prev"><a href="javascript:void(0);">Prev</a></li>
                            <li><a href="javascript:void(0);">1</a></li>
                            <li class="active"><a href="javascript:void(0);">2</a></li>
                            <li><a href="javascript:void(0);">3</a></li>
                            <li class="next"><a href="javascript:void(0);">Next</a></li>
                        </ul> -->
                    </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- <div class="profile_container">
        
        <div class="inner_profile">
            <div class="img">
                <img src="profile_images/<?php echo $user_data->user_image; ?>" alt="Profile image">
            </div>
            <h1><?php echo  $user_data->username;?></h1>
        </div> -->
        <!-- <div class="all_users">
            <h3>All request senders</h3>
            <div class="usersWrapper">
                <?php
                if($get_req_num > 0){
                    foreach($get_all_req_sender as $row){
                        echo '<div class="my_user_box">
                                <div class="my_user_img"><img src="profile_images/'.$row->user_image.'" alt="Profile image"></div>
                                <div class="my_user_info"><span>'.$row->username.'</span>
                                <span><a href="edit-profile.php?id='.$row->sender.'" class="see_profile_button">See profile</a></div>
                            </div>';
                    }
                }
                else{
                    echo '<h4>You have no friend requests!</h4>';
                }
                ?>
            </div>
        </div> -->
       
    </div>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
</body>
</html>