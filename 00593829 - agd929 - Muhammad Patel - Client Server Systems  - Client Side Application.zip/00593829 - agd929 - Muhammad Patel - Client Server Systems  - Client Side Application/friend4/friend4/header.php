
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
    <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <style>
        
        @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");
            a {
                font-family: "Poppins", sans-serif !important;
            }
            body{
                font-family: "Poppins", sans-serif !important;
            }
                #brand-logo {
                        font-size: 34px
                    }

            #app-navbar {
                background: linear-gradient(287deg, #f90c2afc, #5a84eb);
            }
            .nav-item{
                
                padding: 0 5px !important;
            }

            @media screen and (min-width: 480px) {
                .nav-link{
                position: relative;
                /* padding: 0 10px !important; */
            }
            .nav-link:after
           {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            margin: auto;
            width: 0%;
            content: '.';
            color: transparent;
            background: #fff;
            height: 1px;
            transition: width 1s;
            opacity: 0;
            }

            .nav-link:hover:after {
                width: 100%;
                opacity: 1;
            }
                }            
           
            body {
                background: white;
}


    body {
    margin: 0;
    padding: 0;
    height: 100vh;
    background: rgba(255, 255, 255, 0.5) url('php-examples.jpeg') no-repeat;
    background-size: cover;
    background-position: bottom;
    display: flex;
    flex-wrap: nowrap;
    flex-direction: column;
    justify-content: center;
    font-family: 'Poppins', sans-serif !important;
  }
  #login .container #login-row #login-column #login-box {
    margin-top: 50px;
    max-width: 600px;
    /* height: 320px; */
    border: 1px solid #9C9C9C;
    background-color: #fff;
    padding: 30px;
}

 

  .overlay{
    background: black;
    position: absolute;
    top: 0%;
    opacity: 0.2;
    height: 100vh;
    width: 100vw;
}

.text-black{
    color: black
}
    </style>


    <style type="text/css">
        @media screen {
            @font-face {
                font-family: 'Lato';
                font-style: normal;
                font-weight: 400;
                src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format('woff');
            }

            @font-face {
                font-family: 'Lato';
                font-style: normal;
                font-weight: 700;
                src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format('woff');
            }

            @font-face {
                font-family: 'Lato';
                font-style: italic;
                font-weight: 400;
                src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format('woff');
            }

            @font-face {
                font-family: 'Lato';
                font-style: italic;
                font-weight: 700;
                src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format('woff');
            }
        }

        /* CLIENT-SPECIFIC STYLES */
        body,
        table,
        td,
        a {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            -ms-interpolation-mode: bicubic;
        }

        /* RESET STYLES */
        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
        }

        table {
            border-collapse: collapse !important;
        }

        body {
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
        }

        /* iOS BLUE LINKS */
        a[x-apple-data-detectors] {
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        /* MOBILE STYLES */
        @media screen and (max-width:600px) {
            h1 {
                font-size: 32px !important;
                line-height: 32px !important;
            }
        }

        /* ANDROID CENTER FIX */
        div[style*="margin: 16px 0;"] {
            margin: 0 !important;
        }


       /* ////Multi level dropdown quiz */

        .dropdown-menu li {
        position: relative;
        }
        .dropdown-menu .dropdown-submenu {
        display: none;
        position: absolute;
        left: 100%;
        top: -7px;
        }
        .dropdown-menu .dropdown-submenu-left {
        right: 100%;
        left: auto;
        }
        .dropdown-menu > li:hover > .dropdown-submenu {
        display: block;
        }


        a#curs_section.active  {
        background: #007bff;
        color: rgb(236, 236, 237);


        }

        /* ///////Progress Circle */

        .circle {
  width: 200px;
  margin: 6px 6px 20px;
  display: inline-block;
  position: relative;
  text-align: center;
  line-height: 1.2;
}

.circle canvas {
  vertical-align: top;
  width: 100px !important;
}

.circle strong {
  position: absolute;
  top: 30px;
  left: 0;
  width: 100%;
  text-align: center;
  line-height: 40px;
  font-size: 22px;
  color: black;
}

.circle strong i {
  font-style: normal;
  font-size: 0.6em;
  font-weight: normal;
}

.circle span {
  display: block;
  color: #aaa;
  margin-top: 12px;

}




    </style>
</head>
<body>

<p style="background-image: url('php-examples.jpeg');">
<nav class="navbar navbar-dark navbar-expand-md" id="app-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="{{url('/user')}}">
            <img src="{{asset('images/logo/logo.png')}}" style="height: 60px;" alt="Logo">
            <img src="profile_images/<?php echo $user_data->user_image; ?>" alt="Profile image">
        </a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1">
                <span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span>
            </button>

        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
             

     
     


            <li class="dropdown nav-item" role="presentation">
                <a href="" class="nav-link active" data-toggle="dropdown">
                Home
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
             
                    <li>
                      
                      <a class="dropdown-item" href="#">
                          
                      </a>
                     
                      <ul class="dropdown-menu dropdown-submenu">

                         
                          <li>
                            <a class="dropdown-item" href="my-profile.php"> </a>
                          </li>
                   

                      </ul>
                
                    </li>
                   
                  </ul>
            </li>
 




            <li class="nav-item" role="presentation"><a class="nav-link" href="notify.php" rel="noopener noreferrer">Requests<span class="badge <?php
                if($get_req_num > 0){
                    echo 'redBadge';
                }
                ?>"><?php echo $get_req_num;?></span></a></li>
               <li class="nav-item" role="presentation"><a  class="nav-link" href="my-friends.php" rel="noopener noreferrer">
                   Friends<span class="badge"><?php echo $get_frnd_num;?></span></a></li>
               
                <li class="nav-item" role="presentation"><a class="nav-link" href="edit-profile.php">edit<span class="badge"> </span></a></li>
                <li class="nav-item" role="presentation"><a class="nav-link"  href="logout.php" rel="noopener noreferrer">Logout</a></li>
             
            </ul>




            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
             
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}"> </a>
                        </li>
              

              
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}"> </a>
                        </li>
                
           



                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                       
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('profile-edit.index') }}">Profile</a>
                            <a class="dropdown-item" href="{{ url('profile/'.$login_user) }}">Progress</a>


                         
                        </div>



                    </li>
         
            </ul>
        </div>
    </div>
</nav>


<!--Navbar blue-->
<nav class="navbar navbar-expand-lg navbar-dark teal mb-4">
  <a class="navbar-brand" href="#">Navbar</a>
  <button
    class="navbar-toggler"
    type="button"
    data-toggle="collapse"
    data-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent"
    aria-expanded="false"
    aria-label="Toggle navigation"
  >
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"
          >Home <span class="sr-only">(current)</span></a
        >
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pricing</a>
      </li>
      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle"
          id="navbarDropdownMenuLink"
          data-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          >Dropdown
        </a>
        <div
          class="dropdown-menu dropdown-primary"
          aria-labelledby="navbarDropdownMenuLink"
        >
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
    </ul>
    <form class="form-inline">
      <input
        class="form-control mr-sm-2"
        type="text"
        placeholder="Search"
        aria-label="Search"
      />
    </form>
  </div>
</nav>
<!--/.Navbar blue-->


